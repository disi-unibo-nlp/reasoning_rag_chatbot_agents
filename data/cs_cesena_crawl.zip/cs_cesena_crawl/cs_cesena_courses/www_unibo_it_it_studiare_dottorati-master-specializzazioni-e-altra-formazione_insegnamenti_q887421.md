# 70226 - PROGRAMMAZIONE DI RETI

## Anno Accademico
                2024/2025

- Docente:
Franco Callegati
- Crediti formativi:
                        6
- SSD:
                        INF/01
- Lingua di insegnamento:
                        Italiano

- Moduli:
Franco Callegati
                            (Modulo 1)
                        
                        
                            Andrea Piroddi
                            (Modulo 2)
- Modalità didattica:
                        
                        
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 1)
                                
                            
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 2)
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

                            
                                


Valido anche per
                                
                                    
                                    
                                    Laurea in
                                    
                                        Ingegneria biomedica (cod. 9082)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni (Modulo 1)

dal 20/02/2025 al 30/05/2025
- Orario delle lezioni (Modulo 2)

dal 04/03/2025 al 20/05/2025

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente acquisisce le nozioni essenziali sulle architetture di rete e sulle problematiche di progettazione e implementazione di protocolli di comunicazione.

## Contenuti

L'obiettivo dell'insegnamento e' quello di presentare i problemi riguardanti la progettazione e l'implementazione delle moderne applicazioni di rete. Le varie tematiche vengono presentate in due fasi, la prima dedicata allo studio del problema in termini generali, la seconda orientata a mostrare come tali soluzioni trovino implementazione nelle soluzioni tecnologiche correnti.

Vengono presentati e discussi i seguenti argomenti.

- Internet e reti di calcolatori: Internet, protocolli, programmi client e server, livelli di protocollo e modelli di servizio, architettura a livelli.
- Analisi di protocollo: Sniffing, acquisizione ed utilizzo di tracce per l'analisi ed il debug. Utilizzo dell'analizzatore Wireshark.
- Livello di applicazione: protocolli a livello applicazione (Web e HTTP, FTP, SMTP, POP3, IMAP, DNS), architetture P2P (BitTorrent), utilizzo delle socket (o costrutti affini) in vari linguaggi di programmazione.
- Livello di trasporto: servizi, multiplexing e demultiplexing, trasporto senza connessione, protocollo UDP, principi del trasferimento dati affidabile, trasporto orientato alla connessione, protocollo TCP, cause e costi della congestione, approcci al controllo di congestione, controllo di congestione TCP.
- Cenni alla sicurezza delle applicazioni: autenticazione, autorizzazione, certificati digitali.

## Testi/Bibliografia

Achille Pattavina, "Internet e reti. Fondamenti." Pearson; 3° edizione (9 febbraio 2022), 576 pagine, ISBN 8891930911

## Metodi didattici

Il primo modulo dell'insegnamento si compone esclusivamente di lezioni frontali (40 ore), le lezioni di laboratorio sono demandate al secondo modulo (16 ore).

## Modalità di verifica e valutazione dell'apprendimento

Le modalità di svolgimento della prova d'esame sono spiegate nella pagina del corso sulla piattaforma Virtuale.

## Strumenti a supporto della didattica

Il materiale didattico presentato a lezione viene messo a disposizione degli studenti in formato elettronico sulla piattaforma Virtuale.

## Orario di ricevimento

Consulta il sito web di
                    
                        Franco Callegati

Consulta il sito web di
                        
                            Andrea Piroddi

### SDGs

<!-- image -->

L'insegnamento contribuisce al perseguimento degli Obiettivi
            di Sviluppo Sostenibile dell'Agenda 2030 dell'ONU.