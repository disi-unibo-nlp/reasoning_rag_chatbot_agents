# 77780 - SISTEMI EMBEDDED E INTERNET-OF-THINGS

## Anno Accademico
                2024/2025

- Docente:
Alessandro Ricci
- Crediti formativi:
                        6
- SSD:
                        ING-INF/05
- Lingua di insegnamento:
                        Italiano

- Modalità didattica:
Convenzionale - Lezioni in presenza
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

                            
                                


Valido anche per
                                
                                    
                                    
                                    Laurea Magistrale in
                                    
                                        Ingegneria e scienze informatiche (cod. 8614)

- Risorse didattiche su Virtuale

- Orario delle lezioni

dal 19/09/2024 al 18/12/2024

## Conoscenze e abilità da conseguire

Al termine del corso lo studente conosce gli elementi introduttivi circa i metodi e le tecnologie per la progettazione e sviluppo di sistemi embedded e di sistemi basati M2M/Internet of Things, ed in grado di svolgere progetti su tecnologie basate su microcontrollori e su sistemi operativi embedded/realtime. 
Più nel dettaglio lo studente possiede:
la conoscenza dello spettro applicativo relativo ai sistemi embedded, includendo evoluzioni recenti quali Cyber-Physical Systems, M2M e Internet-of-Things (IoT);
una conoscenza di base dell'harware dei sistemi embedded, dagli aspetti relativi all'elettronica di base alle schede basate su micro-controllori e SoC (System-on-a Chip);
la conoscenza delle tecniche di programmazione di sistemi embedded, dei protocolli e tecniche di interfacciamento con sensori e attuatori, dei protocolli e dei modelli di comunicazione a supporto della visione IoT; la conoscenza delle principali problematiche relative alla costruzione di sistemi software embedded - in merito ad aspetti di concorrenza, reattività, real-time, gestione dell'I/O, distribuzione - e quindi dei metodi e meta-modelli di riferimento per la modellazione e progettazione di tali sistemi (macchine a stati finiti sincrone/asincrone, modelli a task, modelli ad attori); la conoscenza dell¡¯organizzazione e funzionamento di sistemi operativi embedded e real-time, degli aspetti di base relativi alla programmazione real-time, e dei middleware e piattaforme per lo sviluppo ad alto livello di sistemi embedded e articolati;
la capacità di sviluppare progetti di base di sistemi embedded basati su microcontrollori e SoC utilizzando come tecnologie di riferimento per il settore.

## Contenuti

Il corso concerne la progettazione e sviluppo di sistemi software per sistemi embedded, ovvero sistemi informatici/elettronici che interagiscono con il mondo fisico mediante sensori e attuatori, estendendone o definendone le funzionalità. Tra questi, il corso considera - in modo introduttivo - anche la programmazione di sistemi IoT (Internet of Things), considerando l’integrazione mediante la rete Internet e reti wireless a corto raggio di sistemi embedded con sistemi informatici lato server (web service) e applicazioni in esecuzione su dispositivi mobili (smartphone, tablet). Al termine del corso lo studente è in grado di sviluppare embedded software su tecnologie embedded quali microcontrollori, sistemi SoC (system-on-a-chip), integrati in rete con sistemi/applicazioni web e applicazioni mobile.

Contenuti nel dettaglio

- Introduzione ai sistemi embedded e Internet of Things (IoT)

-- caratteristiche, tipologie, architetture e tecnologie hardware, applicazioni di riferimento

-- introduzione agli aspetti elettronici di base, alla sensoristica e ai sistemi di attuazione

- Tecniche di programmazione di sistemi embedded

-- modelli a super-loop

-- modelli a macchine a stati finiti sincrone e asincrone

-- modelli a task e ad eventi

-- supporti e tecniche basate su Sistemi Operativi Embedded e Real-Time

- Reti di sistemi embedded e sistemi IoT (introduzione)

-- modelli, architetture, protocolli di comunicazione per reti di dispositivi

-- modelli a scambio di messaggi asincrono

-- Framework IoT e piattaforme/middleware di supporto

- Cenni su temi avanzati

-- Web of Things (WoT)

-- Digital Twins

-- From IoT to Augmente/Mixed Reality and Back: Mirror/Augmented Worlds

In laboratorio:

- Arduino UNO come piattaforma a micro-controllore

-- introduzione al linguaggio C++ e framework Wiring, utilizzato per implementare i programmi su Arduino

- ESP32 come piattaforma SoC e FreeRTOS come sistema operativo real-time

## Testi/Bibliografia

- An Embedded Software Primer (David E. Simon) - Addison Wesley

- Programming Embedded Systems: An Introduction to Time-Oriented Programming (Vahid, Givargis, Miller)

- Patterns of Time Triggered Embedded Systems (M. Pont) - Addison Wesley

- Exploring Arduino: Tools and Techniques for Engineering Wizardry. J. Blum. Wiley

- Design Patterns for Embedded Systems in C (B.P. Douglas) - Elsevier

- The Internet of Things (S. Greengard) - MIT Press

- Learning Internet of Things (P. Waher) - Packt

- Building Internet of Things with The Arduino (C. Doukas)

- Designing the Internet of Things (McEwen &amp; Cassimally) - Wiley

## Metodi didattici

I vari argomenti del programma sono trattati integrando in modo continuo la presentazione e discussione in aula degli aspetti concettuali e teorici e lo sviluppo concreto di esempi e sistemi in laboratorio. Per quest'ultima si promuove il lavoro di gruppo, con la possibilità di svolgere consegne svolte man mano durante il corso.

## Modalità di verifica e valutazione dell'apprendimento

La verifica dell'apprendimento avviene mediante un colloquio in cui si discutono le consegne svolte durante l'anno o, in alternativa, un progetto concordato con il docente e svolto prima del colloquio.

La discussione parte dalle soluzioni concrete adottate nei sistemi sviluppati per poi entrare nel merito delle parti più concettuali e teoriche viste nel corso.

## Strumenti a supporto della didattica

Durante le lezioni verranno proiettati lucidi, disponibili sul sito ufficiale del corso. A supporto delle attività pratiche, verrà utilizzato il laboratorio di informatica ove gli studenti troveranno gli strumenti necessari per svolgere le esercitazioni - a partire da kit con Arduino e ESP.

## Link ad altre eventuali informazioni

https://virtuale.unibo.it/course/view.php?id=48303

## Orario di ricevimento

Consulta il sito web di
                    
                        Alessandro Ricci