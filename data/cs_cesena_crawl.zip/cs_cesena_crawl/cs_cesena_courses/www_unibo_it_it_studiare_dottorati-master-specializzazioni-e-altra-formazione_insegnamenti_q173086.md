# Insegnamenti

Hai cercato:
11929,
        
        
        
        
          corso Ingegneria e scienze informatiche (cod. 8615) - L,
        
        
        
        
        nell'A.A.
        2024/2025

Risultati
              1

- 11929 - ALGORITMI E STRUTTURE DATI Crediti formativi: 12 Ambito: Ingegneria e architettura ; Scienze Campus di Cesena SSD: INF/01 Laurea in Ingegneria e scienze informatiche (cod. 8615) FIGLI END FIGLI
- Ambito:
                Ingegneria e architettura ; Scienze
- Campus di
                Cesena
    - 11929 - ALGORITMI E STRUTTURE DATI (CL.A) Luciano Margara NIPOTI END NIPOTI
        - 11929 - ALGORITMI E STRUTTURE DATI (Modulo 1)
Luciano Margara


Orario delle lezioni
				dal 17/02/2025 al 26/05/2025
        - 11929 - ALGORITMI E STRUTTURE DATI (Modulo 2)
Moreno Marzolla


Orario delle lezioni
				dal 21/02/2025 al 30/05/2025
    - 11929 - ALGORITMI E STRUTTURE DATI (CL.B) Vittorio Maniezzo NIPOTI END NIPOTI
        - 11929 - ALGORITMI E STRUTTURE DATI (Modulo 1)
Vittorio Maniezzo


Orario delle lezioni
				dal 17/02/2025 al 20/05/2025
        - 11929 - ALGORITMI E STRUTTURE DATI (Modulo 2)
Moreno Marzolla


Orario delle lezioni
				dal 20/02/2025 al 29/05/2025