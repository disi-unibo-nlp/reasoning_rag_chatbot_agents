# 77776 - MATEMATICA DISCRETA E PROBABILITÀ

## Anno Accademico
                2024/2025

- Docente:
Fabrizio Caselli
- Crediti formativi:
                        6
- SSD:
                        MAT/02
- Lingua di insegnamento:
                        Italiano

- Modalità didattica:
Convenzionale - Lezioni in presenza
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni

dal 18/09/2024 al 13/12/2024

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente possiede alcuni strumenti elementari di combinatoria e numerativa e di probabilità.

## Contenuti

Nozioni di base del calcolo combinatorio. Liste, disposizioni, permutazioni e combinazioni. Il principio di inclusione-esclusione. Partizioni. Numeri di Bell e di Stirling. Elementi di statistica descrittiva. Indici di posizione e di dispersione. Teoria assiomatica della probabilità: eventi, eventi elementari. Probabilità condizionata, eventi indipendenti. Teorema delle probabilità totali e teorema di Bayes. Variabili aleatorie discrete. Variabili bernoulliane, variabile geometrica, ipergeometrica, di Poisson. Valore atteso, varianza. Variabili aleatorie multidimensionali. Densità marginali e congiunte. Legge dei grandi numeri. Variabili aleatorie continue. Densità uniforme, esponenziale, normale. Valore atteso, varianza. Teorema centrale del limite. Elementi di statistica inferenziale.

## Testi/Bibliografia

Paolo Baldi, Introduzione alla probabilità, con elementi di statistica, Seconda edizione, McGraw-Hill

F.Caselli, Note di Matematica discreta e probabilità, disponibili online

## Metodi didattici

Lezioni frontali. Almeno un'ora la settimana è dedicata alla risoluzione alla lavagna da parte del docente e degli studenti di esercizi assegnati durante la lezione precedente.

## Modalità di verifica e valutazione dell'apprendimento

La prova d'esame ha lo scopo di verificare il raggiungimento dei seguenti obiettivi: conoscenza approfondita degli strumenti combinatorici e probabilistici presentati durante il corso; capacità di utilizzare gli strumenti forniti per risolvere un problema di combinatoria e probabilità.

La prova d'esame è costituita da una prova scritta e da una prova orale. Per partecipare a ciascuna prova è necessaria l'iscrizione al relativo appello sul sito AlmaEsami.

La prova scritta prevede la risoluzione di esercizi e di problemi riguardanti la combinatoria e la probabilità e mira a valutare la capacità dello studente di saper applicare gli strumenti teorici forniti. Esempi di prove scritte sono facilmente reperibili sulla pagina del sito Virtuale dedicata al corso. Durante la prova scritta non è ammesso l'uso di libri o appunti, ma solo l'utilizzo di una calcolatrice. La valutazione dello scritto è in trentesimi e prevede una votazione minima di 15/30 per essere ammessi alla prova orale. I risultati vengono inseriti sul sito AlmaEsami.

La prova orale verte a verificare la conoscenza teorica della materia prescindendo quindi dalle eventuali applicazioni. In occasione della prova orale viene sempre effettuata la discussione della prova scritta. La valutazione finale terrà conto delle due prove nel loro complesso e la relativa verbalizzazione viene effettuata al termine della prova orale.

Sono previsti sei appelli nell'arco dell'anno accademico: tre nella sessione invernale Gennaio-Febbraio, due nella sessione estiva Giugno-Luglio e una nella sessione autunnale di Settembre. Le loro date esatte saranno disponibili sul sito AlmaEsami con ampio anticipo.

## Strumenti a supporto della didattica

Materiale didattico consistente in registro aggiornato delle lezioni, esercizi assegnati e relative soluzioni, temi d'esame assegnati negli anni accademici precedenti e note aggiuntive del docente saranno disponibili sul sito Virtuale del corso

## Orario di ricevimento

Consulta il sito web di
                    
                        Fabrizio Caselli