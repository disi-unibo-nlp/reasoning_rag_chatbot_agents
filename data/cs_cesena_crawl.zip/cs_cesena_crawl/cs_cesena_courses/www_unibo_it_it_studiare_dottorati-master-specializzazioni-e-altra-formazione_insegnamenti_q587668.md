# 96642 - VIRTUALIZZAZIONE E INTEGRAZIONE DI SISTEMI

## Anno Accademico
                2024/2025

- Docente:
Vittorio Ghini
- Crediti formativi:
                        6
- SSD:
                        INF/01
- Lingua di insegnamento:
                        Italiano

- Moduli:
Vittorio Ghini
                            (Modulo 1)
                        
                        
                            Ciro Barbone
                            (Modulo 2)
                        
                        
                            Enrico Fiumana
                            (Modulo 3)
- Modalità didattica:
                        
                        
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 1)
                                
                            
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 2)
                                
                            
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 3)
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Risorse didattiche su Virtuale

- Orario delle lezioni (Modulo 1)

dal 18/02/2025 al 28/05/2025
- Orario delle lezioni (Modulo 2)

dal 29/04/2025 al 20/05/2025
- Orario delle lezioni (Modulo 3)

dal 25/03/2025 al 15/04/2025

## Conoscenze e abilità da conseguire

Al termine del corso lo studente: conosce i principi fondamentali della virtualizzazione, dei sistemi di gestione dell'identità, dei sistemi di protezione delle reti (firewall in particolare); conosce i principali fattori che ostacolano il dispiegamento di servizi e applicazioni distribuiti, in contesti eterogenei in termini di utenti, servizi e sistemi operativi; conosce i principali metodi e strumenti utilizzabili per progettare e dispiegare applicazioni distribuite; conosce i principali protocolli, sistemi e strumenti per consentire l'interazione tra servizi di base offerti da sistemi operativi diversi; conosce le principali piattaforme di gestione di cloud on premise; conosce i principali protocolli, strumenti e piattaforme per configurare, dispiegare, manutenere e monitorare, in modo centralizzato e automatizzato, sistemi, servizi e applicazioni distribuiti.

## Contenuti

Il corso fornisce le conoscenze e le abilità della figura professionale del System Integration and Testing Engineer.

Sono indispensabili, per la comprensione dei contenuti del corso, solide conoscenze pregresse maturate nei corsi di programmazione, sistemi operativi e reti di calcolatori.

- La figura professionale del System Integration and Testing Engineer, i suoi task e le sue competenze .

- Casi di studio più significativi.

- Richiami sulla Gestione locale di un sistema.

- Cenni su sicurezza dei sistemi informatici, delle server farm e delle reti. Protocolli e utilities, ssh, tls/ssl, dtls.
- Richiami di gestione delle reti, strumenti essenziali, filtering, iptables/netfilter.
- Protocolli di rete (OPC) per interazioni con sistemi industriali (PLC).
- Cenni su Protezione delle reti locali e delle server farm, Firewall e protocolli per superamento di NAT, Proxy/Relay, protocolli e strumenti per proxying, Socks.

- Principi di Virtualizzazione. Piattaforme di virtualizzazione. Container. Applicazioni della virtualizzazione: dalle server farm agli smartphone.
- Architetture a Microservizi: architetture software language-independent a componenti. Bus dei messaggi (a livello kernel, locali e in cloud). Esempi notevoli di architetture a Microservizi in ambito locale e in ambito cloud.
- Un esempio di virtualizzazione a livello di container: Docker.
Le API di docker. Le reti virtuali tra container di docker.

    Costruire un immagine di container automaticamente mediante Dockerfile; Introduzione a Docker Compose;

    Docker Swarm - eseguire applicazioni multicontainer in cluster di host utilizzando uno strumento nativo di docker.

    Kubernetes: Orchestrazione di macchine virtuali, servizi e containers. Prodotti per orchestrazione on premise su cluster o su singolo nodo (minikube).
- Cenni su Piattaforme di Gestione di Cloud on premise.

- IDentity Management (IDM). IDM a base Windows (Active Directory, LDAP) e Linux (Kerberos, openLDAP) .

- Interazioni tra sistemi Windows e Linux, esempi, casi di studio.

- Gestione centralizzata di servizi distribuiti e sviluppo di applicazioni di supporto: Monitoraggio centralizzato, protocolli, applicazioni, SNMP, Nagios e altri applicativi similari. Configurazione centralizzata. Autenticazione centralizzata. Manutenzione centralizzata. Sviluppo di applicazioni distribuite, in particolare per monitoraggio e configurazione dinamica di sistemi locali e distribuiti.

## Testi/Bibliografia

dispense del docente pubblicate sul sito personale a partire dall'inizio delle lezioni (vedi link).

## Metodi didattici

Lezioni Frontali e Esercitazioni in aula e in laboratorio informatico.

I fondamenti teorici sono esposti durante le lezioni frontali. Numerosi esercizi pratici sono svolti in aula ad anticipare gli esercizi che gli studenti dovranno successivamente svolgere nelle esercitazioni guidate in laboratorio, con la supervisione del docente.

Estensioni delle esercitazioni sono regolarmente suggerite, e le soluzioni pubblicate sul web, allo scopo di promuovere e favorire lo studio individuale e le attività di laboratorio autonome.

Alcune esercitazioni in aula e in laboratorio sono dedicate a simulare lo svolgimento della prova teorico/pratica che costituisce la prova d'esame.

In considerazione della tipologia di attività e dei metodi didattici adottati, la frequenza di questa attività formativa richiede la preventiva partecipazione di tutti gli studenti ai moduli 1 e 2 di formazione sulla sicurezza nei luoghi di studio, in modalità e-learning [ https://corsi.unibo.it/laurea/IngegneriaScienzeInformatiche/formazione-obbligatoria-su-sicurezza-e-salute ].

## Modalità di verifica e valutazione dell'apprendimento

L'esame consiste di una verifica teorico/pratica delle conoscenza degli aspetti teorici e pratici della disciplina, effettuata mediante una prova scritta;

La prova teorico/pratica consiste di una prova scritta che dura 1 ora e prevede risposte aperte ad una serie di domande ed alcuni semplici esercizi. La prova teorico/pratica scritta spazia tra tutti gli argomenti presentati durante il corso.

Se la prova teorico/pratica viene superata, il voto viene verbalizzato dopo 2 settimane. Lo studente ha perciò due settimane di tempo per rifiutare il voto.

## Strumenti a supporto della didattica

Lezioni: proiezione di diapositive a disposizione via Web e dimostrazioni pratiche dei concetti, algoritmi, tecniche, API e strumenti esposti nelle discussioni a lezione. Le dimostrazioni pratiche utilizzano script e files che sono preventivamente messi a disposizione nella pagina web del corso. In tal modo, gli studenti possono meglio seguire le dimostrazioni e replicarle durante la stessa lezione sui loro laptop, verificando personalmente lo sviluppo delle operazioni e individuando e proponendo immediatamente al docente eventuali dubbi, così da sollecitare al massimo l'interazione tra studenti e docente durante le lezioni.

Attività in laboratorio: il docente guida gli studenti nell'imparare progressivamente gli strumenti, le API e le strategie di risoluzione dei problemi concernenti tutti gli argomenti del corso. A ciascuno studente è fornito un proprio ambiente di lavoro virtualizzato, in cui lo studente opera con i privilegi di amministratore di sistema, in modo da effettuare realisticamente procedure operative di amministrazione dei sistemi.

## Link ad altre eventuali informazioni

http://www.cs.unibo.it/~ghini/didattica/systemsintegration/index.html

## Orario di ricevimento

Consulta il sito web di
                    
                        Vittorio Ghini

Consulta il sito web di
                        
                            Ciro Barbone

Consulta il sito web di
                        
                            Enrico Fiumana

### SDGs

<!-- image -->

<!-- image -->

<!-- image -->

L'insegnamento contribuisce al perseguimento degli Obiettivi
            di Sviluppo Sostenibile dell'Agenda 2030 dell'ONU.