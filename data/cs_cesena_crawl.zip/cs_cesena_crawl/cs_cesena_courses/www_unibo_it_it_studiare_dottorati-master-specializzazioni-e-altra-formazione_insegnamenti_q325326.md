# 72796 - PROGRAMMAZIONE DI APPLICAZIONI DATA INTENSIVE

## Anno Accademico
                2024/2025

- Docente:
Gianluca Moro
- Crediti formativi:
                        6
- SSD:
                        ING-INF/05
- Lingua di insegnamento:
                        Italiano

- Modalità didattica:
Convenzionale - Lezioni in presenza
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni

dal 17/02/2025 al 09/06/2025

## Conoscenze e abilità da conseguire

Al termine del corso lo studente è in grado di progettare e sviluppare componenti e applicazioni per gestire ed elaborare dati strutturati e destrutturati in scenari di interesse aziendale, impiegando moderne architetture e tecnologie di rete e di accesso a basi di dati remote.

## Contenuti

IL CORSO TRATTA I FONDAMENTI DI DATA SCIENCE E MACHINE LEARNING, DAGLI ALGORITMI DI BASE ALLE RETI NEURALI PER LO SVILUPPO DI APPLICAZIONI DI INTELLIGENZA ARTIFICIALE IN PYTHON.

Con gli algoritmi di machine learning saranno sviluppati modelli e applicazioni capaci di fare previsioni di varia natura: applicazioni per predire ad esempio l'andamento della borsa valori, predire quali prodotti/servizi acquisterà ogni cliente, prevedere l'andamento delle vendite aziendali, i consumi energetici, il valore di immobili, se un prestito bancario sarà restituito etc

Inoltre il machine learning sarà applicato al natural language processing per classificare opinioni e recensioni di utenti su prodotti/servizi pubblicati in social network e nelle piattaforme di e-commerce. Infine saranno sviluppate applicazioni di question answering per fornire assistenza ad utenti con chatbot, come sviluppare motori di ricerca semantici e come sono realizzati sistemi di questo tipo in medicina per la diagnosi di patologie o per indicare come trattare i sintomi di un paziente descritti in linguaggio naturale.

Dettagli sui contenuti del programma del corso

https://bit.ly/3aG9Brb

Materiale delle lezioni e laboratori

sito web del corso con materiale didattico e laboratori con soluzioni  (https://virtuale.unibo.it/course/view.php?id=52948)

Non sono richieste propedeuticità o conoscenze pregresse poiché i concetti, incluso il linguaggio Python, sono spiegati da zero.

L'accesso al materiale non è vincolante per l'iscrizione al corso (scegliere iscrizione spontanea per visionare il materiale)

## Testi/Bibliografia

- Dispense e riferimenti bibliografici forniti dal docente

Testo consigliato (non obbligatorio)

- Data Science con Python, Dai Fondamenti al Machine Learning. Joel Grus, 2021. Gianluca Moro, curatore scientifico dell'edizione italiana. EGEA Casa Editrice dell'Università Bocconi. Edizione in inglese, O’Reilly Media (versione precedente)

## Metodi didattici

Lezioni in aula affiancate da esercitazioni assistite in laboratorio su casi di studio reali di machine learning e data science per lo sviluppo di applicazioni di intelligenza artificiale in diversi domini aziendali e sociali.

## Modalità di verifica e valutazione dell'apprendimento

Progetto di laboratorio svolto in gruppo, con possibilità di scegliere il tema di AI di interesse, e discussione orale individuale del progetto.

## Strumenti a supporto della didattica

- slide delle lezioni e delle attività di laboratorio disponibili in anticipo
- tecnologie open source python e jupyter disponibili nei laboratori della scuola
- attività di laboratorio assistite fruibili anche online in remoto mediante open cloud computing come colab o binder
- esempio di attività di laboratorio in python fruibile con google colab

Link ai contenuti delle lezioni dell'a.a. 2022/23. I contenuti di machine learning per l'a.a. 2023/24 sono in corso di aggiornamento con le più recenti soluzioni della comunità accademica ed aziendale di AI:

https://virtuale.unibo.it/course/view.php?id=37961

## Orario di ricevimento

Consulta il sito web di
                    
                        Gianluca Moro

### SDGs

<!-- image -->

<!-- image -->

<!-- image -->

L'insegnamento contribuisce al perseguimento degli Obiettivi
            di Sviluppo Sostenibile dell'Agenda 2030 dell'ONU.