# 70090 - COMPUTER GRAPHICS

## Anno Accademico
                2024/2025

- Docente:
Damiana Lazzaro
- Crediti formativi:
                        6
- SSD:
                        MAT/08
- Lingua di insegnamento:
                        Italiano

- Modalità didattica:
Convenzionale - Lezioni in presenza
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni

dal 18/09/2024 al 18/12/2024

## Conoscenze e abilità da conseguire

Al termine del corso lo studente possiede gli elementi di base della grafica al calcolatore, allo scopo sia di utilizzare con competenza i principali software commerciali che  di realizzare interfacce grafiche mediante l'utilizzo delle librerie OpenGL per la modellazione di curve e superfici a forma libera, la realizzazione di tools interattivi per la manipolazione e il rendering  di oggetti 3D.

## Contenuti

Introduzione alla Computer Graphics: Campi di applicazione,
Grafica raster , grafica vettoriale.

Hardware Grafico. Pipeline di rendering : sottosistema
geometrico, sottosistema raster .

Trasformazioni geometriche piane. Trasformazioni di vista.

Librerie OpenGL 4.3 e Visual Studio C++ per la realizzazione
di  applicazioni grafiche 2D e 3D .

Linguaggio GLSL per la programmazione di Vertex Shader ed Fragment Shader

Curve Spline – Curve di Bezier – Curve Spline a nodi multipli
–

Curve di Bezier razionali – Curve  Nurbs .

Tecniche di modellazione tridimensionale

Il Processo di rendering : dal modello 3D  all'immagine
fotorealistica (Algoritmi di eliminazione delle superfici nascoste,
Modelli di illuminazione locale, Modelli di Shading , Modelli di
illuminazione globale, Ray Tracing e Radiosity,  Texturing)

Uso del Software Blender per la modellazione e la resa di scene
3D fotorealistiche.

## Testi/Bibliografia

1. J.
Hoschek – D. Lasser,Computer Aided Geometric Design, A.K. Peters
Wellesley Massachussets 1993.

2.G. Farin,
Curves and Surfaces for CADG V Edition,Morgan Kaufmann
Publishers

3.L. Piegel
W.Tiller, The NURBS Book – II Edition,Springer Verlag
1997

4. J.
Foley, A. van Dam, S. Feiner, J. Hughes, Computer Graphics
Principles and Practice, Addison-Wesley, 1997.

## Metodi didattici

Lezioni in aula, esercitazioni in aula, laboratorio
guidato.

In considerazione della tipologia di attività e dei metodi didattici adottati, la frequenza di questa attività formativa richiede la preventiva partecipazione di tutti gli studenti ai Moduli 1 e 2 di formazione sulla sicurezza nei luoghi di studio, [https://elearning-sicurezza.unibo.it/] in modalità e-learning

## Modalità di verifica e valutazione dell'apprendimento

Prova orale alla consegna di un progetto
individuale.

## Orario di ricevimento

Consulta il sito web di
                    
                        Damiana Lazzaro