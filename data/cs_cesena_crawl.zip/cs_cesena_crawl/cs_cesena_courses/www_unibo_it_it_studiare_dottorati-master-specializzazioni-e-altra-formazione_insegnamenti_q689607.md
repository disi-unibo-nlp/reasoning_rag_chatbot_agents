# 10906 - BASI DI DATI

## Anno Accademico
                2024/2025

- Docente:
Annalisa Franco
- Crediti formativi:
                        12
- SSD:
                        ING-INF/05
- Lingua di insegnamento:
                        Italiano

- Modalità didattica:
Convenzionale - Lezioni in presenza
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

                            
                                


Valido anche per
                                
                                    
                                    
                                    Laurea in
                                    
                                        Ingegneria biomedica (cod. 9082)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni

dal 17/02/2025 al 22/05/2025

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente possiede le nozioni fondamentali della tecnologia delle basi di dati relazionali e gli strumenti metodologici necessari per il suo impiego nella progettazione di un sistema informativo.

## Contenuti

- Descrizione ad alto livello dei principali componenti di un RDBMS: Query Optimizer, Transaction Manager, Scheduler, Recovery Manager, Cache Manager, Storage Manager, Access Methods Manager.
- Modelli dei dati: modelli concettuali vs. modelli logici, il modello relazionale.
- Progettazione concettuale: cenni sulle metodologie per l'analisi dei requisiti; il modello concettuale Entity-Relationship (E/R); progettazione concettuale dei dati con schemi E/R.
- Progettazione logica: stima del carico di lavoro, ristrutturazione dello schema, traduzione di entità e associazioni.
- Forme normali: dipendenze funzionali, 1NF, 2NF, 3NF, BCNF.
- Algebra relazionale: operatori di base e derivati.
- Il linguaggio SQL: istruzioni DDL, DML e DCL.
- Le transazioni: proprietà ACID, gestione della concorrenza, protocolli.
- Organizzazioni dei dati e relativi metodi di gestione: organizzazioni sequenziale e ad accesso diretto, indici primari e secondari, B-tree, B*- tree e B+-tree.
- Sviluppo di applicazioni database: panoramica delle diverse modalità di accesso ai dati. Esempi d'uso in Java e C#.
- Descrizione sintetica delle principali architetture client-server. Cenni su DDBMS, Cloud database e sull’evoluzione delle architetture.
- Trend di evoluzione delle tecnologie delle basi di dati. Cenni sui sistemi NoSQL.

## Testi/Bibliografia

Dispense a cura del docente disponibili sulla piattaforma e-learning dell'ateneo.

D. Maio, S. Rizzi, A. Franco. Esercizi di Progettazione di Basi di Dati. Esculapio, 2005.

Testi per approfondimenti

R. Elmasri, S. Navathe. Sistemi di basi di dati – Fondamenti e complementi (settima edizione). Pearson, 2018.

P. Atzeni, S. Ceri, P. Fraternali, S. Paraboschi, R. Torlone. Basi di Dati, McGraw-Hill Italia, 2018.

P. Ciaccia, D. Maio. Lezioni di Basi di Dati. Esculapio, 2002.

## Metodi didattici

Durante le lezioni sono illustrate e discusse in modo approfondito le diverse problematiche connesse con la progettazione e lo sviluppo di sistemi per la gestione di dati.

Il corso è affiancato da esercitazioni guidate in aula e in laboratorio. Queste attività sono programmate in modo che all'interno di ogni esercitazione lo studente possa realizzare praticamente le soluzioni dei problemi delineati in forma teorica durante le lezioni. In considerazione della tipologia di attività e dei metodi didattici adottati, la frequenza di questa attività formativa richiede la preventiva partecipazione di tutti gli studenti ai Moduli 1 e 2 di formazione sulla sicurezza nei luoghi di studio, in modalità e-learning.

## Modalità di verifica e valutazione dell'apprendimento

L'esame è composto di due parti:

1) un elaborato di progetto che consiste nella progettazione e realizzazione di un'applicazione database; l'ammissione alla prova scritta è subordinata alla consegna di un elaborato giudicato idoneo dal responsabile dell'insegnamento;

2) una prova scritta della durata di 2 ore, costituita da un insieme di esercizi e/o domande su vari argomenti trattati nel corso; durante lo svolgimento della prova scritta non è ammessa la consultazione di alcun tipo di materiale.

N.B. Il periodo di conservazione agli atti dell’elaborato di progetto e della prova scritta è di 6 mesi a decorrere dalla verbalizzazione dell’esito dell’esame sostenuto.

## Strumenti a supporto della didattica

Nel laboratorio sono disponibili diversi DBMS (SQL Server, MySQL, Access, Oracle, ...); per le esercitazioni è utilizzato SQL Server o MySQL. Si fa inoltre ricorso ad alcuni strumenti di ausilio alla progettazione di DB. Per lo sviluppo di applicazioni è previsto l'uso dei linguaggi Java e C#.

## Orario di ricevimento

Consulta il sito web di
                    
                        Annalisa Franco

### SDGs

<!-- image -->

L'insegnamento contribuisce al perseguimento degli Obiettivi
            di Sviluppo Sostenibile dell'Agenda 2030 dell'ONU.