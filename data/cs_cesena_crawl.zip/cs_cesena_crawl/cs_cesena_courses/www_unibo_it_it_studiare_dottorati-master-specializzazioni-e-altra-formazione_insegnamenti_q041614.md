# 41731 - TECNOLOGIE WEB

## Anno Accademico
                2024/2025

- Docente:
Silvia Mirri
- Crediti formativi:
                        6
- SSD:
                        INF/01
- Lingua di insegnamento:
                        Italiano

- Moduli:
Silvia Mirri
                            (Modulo 1)
                        
                        
                            Giovanni Delnevo
                            (Modulo 2)
- Modalità didattica:
                        
                        
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 1)
                                
                            
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 2)
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni (Modulo 1)

dal 20/09/2024 al 10/12/2024
- Orario delle lezioni (Modulo 2)

dal 27/09/2024 al 13/12/2024

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente acquisisce competenze di base sullo sviluppo di siti web tramite tecnologie web client side e server side e sulla rappresentazione di documenti tramite markup e fogli di stile.

## Contenuti

- Fondamenti: HTTP, MIME, codifiche caratteri, markup.
- Tecnologie base del web: URI, HTML5, CSS3, JSON.
- Tecnologie server-side per la realizzazione di applicazioni web, in particolare PHP.
- Tecnologie client-side per la realizzazione di applicazioni web: in particolare Javascript.
- Tecniche HCI, User eXperience (UX), accessibilità e usabilità del Web.

## Testi/Bibliografia

Le slide delle lezioni e delle esercitazioni, così come eventuale materiale didattico aggiuntivo saranno rese disponibili su Virtuale.

## Metodi didattici

Lezioni frontali ed esercitazioni in laboratorio informatico.

## Modalità di verifica e valutazione dell'apprendimento

L'esame è diviso in due parti: la presentazione e demo di un progetto di gruppo e una prova scritta individuale.

## Strumenti a supporto della didattica

Le slide delle lezioni e delle esercitazioni, così come eventuale materiale didattico aggiuntivo saranno rese disponibili su Virtuale.

## Orario di ricevimento

Consulta il sito web di
                    
                        Silvia Mirri

Consulta il sito web di
                        
                            Giovanni Delnevo

### SDGs

<!-- image -->

<!-- image -->

L'insegnamento contribuisce al perseguimento degli Obiettivi
            di Sviluppo Sostenibile dell'Agenda 2030 dell'ONU.