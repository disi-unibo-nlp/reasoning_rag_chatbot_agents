# 70219 - PROGRAMMAZIONE AD OGGETTI

## Anno Accademico
                2024/2025

- Docente:
Mirko Viroli
- Crediti formativi:
                        12
- SSD:
                        ING-INF/05
- Lingua di insegnamento:
                        Italiano

- Moduli:
Mirko Viroli
                            (Modulo 1)
                        
                        
                            Danilo Pianini
                            (Modulo 2)
- Modalità didattica:
                        
                        
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 1)
                                
                            
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 2)
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni (Modulo 1)

dal 18/09/2024 al 18/12/2024
- Orario delle lezioni (Modulo 2)

dal 23/09/2024 al 10/12/2024

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente possiede le conoscenze di base del paradigma object-oriented per la costruzione del software, dei suoi principali pattern di progettazione, della sua incarnazione nel linguaggio di programmazione Java e relativo framework, includendo aspetti avanzati quali la gestione delle interfacce grafiche, del multi-threading, e degli eventi.

## Contenuti

- Elementi base di programmazione e progettazione object-oriented
- Il caso del linguaggio Java: panoramica e tool di sviluppo
- Funzionalità base: Classi, oggetti, metodi, campi, istanziazione
- Polimorfismo, ereditarietà e riuso: interfacce e classi astratte
- Aspetti avanzati: genericità, annotazioni, eccezioni, classi
    innestate, lambda expressions.
- Librerie base per la
    costruzione di programmi
- La gestione dell'I/O e della grafica
- Elementi di programmazione concorrente in Java
- Cenno a pattern di
    progettazione e tecniche di programmazione efficace
- Strumenti di sviluppo: JDK, VSCode, Git

## Testi/Bibliografia

Testo di riferimento per il corso: 

 Bruce Eckel. Thinking in Java -- Fourth Edition 

 Testi aggiuntivi: 

 Joshua Block. Effective Java -- Second Edition

Erich Gamma, Richard Elm, Ralph Johnson, John Vlissides.
Design Patterns

 Il corso si avvarrà anche di tutorial e documentazione tecnica
disponibile in rete

## Metodi didattici

9 ore di lezione alla settimana, di norma 6 in aula e 3 in
laboratorio.

In aula vengono illustrate le tecniche di programmazione ad oggetti, i dettagli del linguaggio di programmazione Java, e vengono svolti esercizi stimolando la discussione critica con gli studenti.

In laboratorio, vengono illustrati i vari tool di sviluppo, e vengono assegnati task di sviluppo per esercitare le capacità pratiche degli studenti.

In considerazione della tipologia di attività e dei metodi didattici adottati, la frequenza di questa attività formativa richiede la preventiva partecipazione di tutti gli studenti ai moduli 1 e 2 di formazione sulla sicurezza nei luoghi di studio, [https://elearning-sicurezza.unibo.it/] in modalità e-learning.

## Modalità di verifica e valutazione dell'apprendimento

La verifica avviene in due fasi, non necessariamente ordinate:

1) Prova pratica su programmazione Java in laboratorio. Attraverso 2 esercizi di programmazione Java, che includono test automatizzati o riguardano la produzione di semplici interfacce grafiche, si verifica la capacità dello studente di concludere in tempi brevi e con competenza un semplice task di programmazione/progettazione in Java.

2) Colloquio orale con presentazione di un progetto. A gruppi di 3 persone circa, gli studenti realizzano un progretto di sviluppo software in Java, producendo una relazione che evidenzia requisiti, progrettazione e implementazione. La valutazione di tale relazione include il controllo di qualità della soluzione, e la discussione delle scelte progettuali.

Ogni prova porta ad un punteggio compreso fra 0 e 33, e il voto finale è una media ponderata 60% (migliore dei due voti) - 40% (peggiore dei due voti).

## Strumenti a supporto della didattica

Slide proiettate a lezione e pubblicate sul sito del docente
in anticipo
 
Software: Java Development Kit, VSCode

## Link ad altre eventuali informazioni

http://apice.unibo.it/xwiki/bin/view/MirkoViroli/

## Orario di ricevimento

Consulta il sito web di
                    
                        Mirko Viroli

Consulta il sito web di
                        
                            Danilo Pianini