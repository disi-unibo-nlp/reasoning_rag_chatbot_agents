# Insegnamenti

Hai cercato:
00819,
        
        
        
        
          corso Ingegneria e scienze informatiche (cod. 8615) - L,
        
        
        
        
        nell'A.A.
        2024/2025

Risultati
              1

- 00819 - PROGRAMMAZIONE Crediti formativi: 12 Ambito: Ingegneria e architettura ; Scienze Campus di Cesena SSD: INF/01 Laurea in Ingegneria e scienze informatiche (cod. 8615) FIGLI END FIGLI
- Ambito:
                Ingegneria e architettura ; Scienze
- Campus di
                Cesena
    - 00819 - PROGRAMMAZIONE (CL.A) Antonella Carbonaro NIPOTI END NIPOTI
        - 00819 - PROGRAMMAZIONE (Modulo 1)
Antonella Carbonaro


Orario delle lezioni
				dal 23/09/2024 al 17/12/2024
        - 00819 - PROGRAMMAZIONE (Modulo 2)
Mirko Ravaioli


Orario delle lezioni
				dal 18/09/2024 al 18/12/2024
    - 00819 - PROGRAMMAZIONE (CL.B) Roberto Girau NIPOTI END NIPOTI
        - 00819 - PROGRAMMAZIONE (Modulo 1)
Roberto Girau


Orario delle lezioni
				dal 23/09/2024 al 11/12/2024
        - 00819 - PROGRAMMAZIONE (Modulo 2)
Andrea Piroddi


Orario delle lezioni
				dal 15/10/2024 al 09/12/2024