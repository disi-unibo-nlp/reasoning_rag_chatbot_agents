# Insegnamenti

Hai cercato:
69731,
        
        
        
        
          corso Ingegneria e scienze informatiche (cod. 8615) - L,
        
        
        
        
        nell'A.A.
        2024/2025

Risultati
              1

- 69731 - ARCHITETTURE DEGLI ELABORATORI Crediti formativi: 12 Ambito: Ingegneria e architettura ; Scienze Campus di Cesena SSD: ING-INF/05 Laurea in Ingegneria e scienze informatiche (cod. 8615) FIGLI END FIGLI
- Ambito:
                Ingegneria e architettura ; Scienze
- Campus di
                Cesena
    - 69731 - ARCHITETTURE DEGLI ELABORATORI (CL.A) Davide Maltoni NIPOTI END NIPOTI
        - 69731 - ARCHITETTURE DEGLI ELABORATORI (Modulo 1)
Davide Maltoni


Orario delle lezioni
				dal 17/02/2025 al 22/05/2025
        - 69731 - ARCHITETTURE DEGLI ELABORATORI (Modulo 2)
Matteo Ferrara


Orario delle lezioni
				dal 26/02/2025 al 30/05/2025
    - 69731 - ARCHITETTURE DEGLI ELABORATORI (CL.B) Raffaele Cappelli NIPOTI END NIPOTI
        - 69731 - ARCHITETTURE DEGLI ELABORATORI (Modulo 1)
Raffaele Cappelli


Orario delle lezioni
				dal 18/02/2025 al 22/05/2025
        - 69731 - ARCHITETTURE DEGLI ELABORATORI (Modulo 2)
Matteo Ferrara


Orario delle lezioni
				dal 24/02/2025 al 29/05/2025