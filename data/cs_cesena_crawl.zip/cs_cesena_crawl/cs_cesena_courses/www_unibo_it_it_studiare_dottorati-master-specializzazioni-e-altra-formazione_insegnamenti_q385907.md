# 70227 - INFORMATICA E DIRITTO

## Anno Accademico
                2024/2025

- Docente:
Luisa Dall'Acqua
- Crediti formativi:
                        6
- SSD:
                        IUS/20
- Lingua di insegnamento:
                        Italiano

- Modalità didattica:
In presenza e a distanza - Blended Learning
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Risorse didattiche su Virtuale

- Orario delle lezioni

dal 18/02/2025 al 10/06/2025

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente: 
- acquisisce consapevolezza dell'esistenza di problemi giuridici legati alle nuove tecnologie; 
- comprende come poter sviluppare e utilizzare (come professionista o utente) le nuove tecnologie in modo conforme a leggi e regolamenti; 
- è in grado di reperire da fonti qualificate e di interpretare autonomamente la normativa vigente applicabile al suo ambito di interesse; 
- sviluppa la capacità di gestire progetti che implicano conoscenze giuridiche;
- interagisce in modo qualificato con avvocati ed esperti del diritto.

## Contenuti

Introduzione al corso

Tecnologie emergenti e regolamentazione. La professione dell'ingegnere informatico e il diritto: consulenze, sviluppo di software e imprenditorialità.

Internet delle Cose (IoT) e Protezione dei Dati

Media tradizionali e media digitali. Regolamentazione delle Piattaforme Digitali. Socialnetwork. E-commerce. GDPR e ISO/IEC 27001. Ruolo del DPO. Tecnologie di Sorveglianza e Privacy.

Metaverso - Digital Twins

Regolamentazioni e mondo virtuale. Proprietà Virtuale e Diritti di Proprietà Intellettuale. Identità digitale. Questioni etiche.

Intelligenza Artificiale

“AI act” Europeo. Responsabilità delle decisioni automatizzate. Responsabilità per Danno da Agente Intelligente. Rischi dell'IA generativa. Robotica, IA e diritto. Applicazioni: Sanità, Trasporti, Militare. Questioni etiche.

Governance IT

Il Codice dell’Amministrazione digitale e le recenti modifiche. Contratti Intelligenti e Blockchain. Normative di compliance per le aziende tecnologiche. Brevetti e Copyright. Software in open source. La tutela delle banche dati.

Cybercrime e Intelligence

Tipi di criminalità informatica. Social Engineering. Intelligence, spionaggio informatico e terrorismo informatico. Analisi Forense digitale.

Casi di studio: Analisi di casi reali e discussioni

## Testi/Bibliografia

Il materiale didattico sarà costituito dalle slide delle lezioni e dalle dispense e papers forniti dal docente attraverso la piattaforma Virtual Learning Environment.

Per gli studenti non frequentanti, oltre alle dispense:

- AA.VV. (2024) La regolazione europea della società digitale. Curatore: F. Pizzetti. Ed. Giappichelli

Testi consigliati per eventuali approfondimenti:

- G. Finocchiaro, Intelligenza artificiale. Quali regole?, Zanichelli, Bologna, 2024
- A. Santosuosso, G. Sartor (2024). Decidere con l'IA. Intelligenze artificiali e naturali nel diritto, ed, Il Mulino
- A. Contaldo , F. Peluso (2022). Informatica forense e nuove tecnologie dell’informazione, PM edizioni

## Metodi didattici

Lezioni frontali tenute dal docente. Durante le lezioni saranno analizzati casi pratici e svolte esercitazioni.

Strategia di innovazione didattica

Enfasi sul learning-by-doing con un focus basato sulla pratica. Il modello incentrato sullo studente consente sessioni con attività di lavoro di gruppo specifiche.

Metodologia di innovazione didattica

In particolare, l’attività formativa innovativa, che si svilupperà tramite anche incontri con professionisti nel settore e lavori di gruppo, si baserà su due principali metodologie (guidate dal docente): a) una basata sull’investigazione, che stimola lo studente a formulare domande investigabili, mettere in atto azioni utili a risolvere problemi e comprendere in maniera più profonda i fenomeni presentati; b) una di analisi di gruppo, atta a consentire ai singoli studenti e ai gruppi di essere più ricettivi alle nuove idee, valutando diversi punti di vista, e per svilupparle in modo creativo e costruttivo

## Modalità di verifica e valutazione dell'apprendimento

Per gli studenti frequentanti (almeno il 70%) l'esame si svolgerà in due tempi:

- un test intermedio
- un research work finale da presentare

Il voto sarà espresso in trentesimi e sarà la media delle due valutazioni.

Gli studenti NON frequentanti avranno un test unico finale su tutto il programma ed il libro di testo che sarà indicato.

## Strumenti a supporto della didattica

Possibili strumenti:

- Presentazioni digitali, video, brevi webinar con esperti esterni, pubblicazione di dispense, utilizzo di un forum per domande e chiarimenti in corso, scrittura collaborativa e comunicazione.
- Strumenti multimediali: Virtuale, videoconferencing tool, Apps di comunicazione asincrona e collaborazione, Strumenti di investigazione ed analisi

## Orario di ricevimento

Consulta il sito web di
                    
                        Luisa Dall'Acqua