# Servizi di orientamento

I servizi e le attività di orientamento a supporto della scelta del corso e in ogni fase del percorso formativo.

## Orientamento ​per chi vuole iscriversi

Per aiutarti nella scelta e supportare la preparazione dei test d'accesso puoi rivolgerti al servizio di tutorato. Otterrai informazioni sugli obiettivi formativi, le attività didattiche e gli sbocchi occupazionali e potrai chiarire ogni tuo dubbio.

Contatti:

Elvis Perlika - Tutor di Orientamento: elvis.perlika2@unibo.it

Filippo Berveglieri - Tutor del corso di studio: campuscesena.tutorltisi@unibo.it

Il tutor riceve previo appuntamento via e-mail.

### Attività di orientamento

Il Corso partecipa agli eventi di orientamento promossi dall'Ateneo e organizza altre attività specifiche per presentare agli studenti le caratteristiche del percorso di studio e consentire agli studenti immatricolati di iniziare gli studi con tutte le informazioni necessarie.

- AlmaOrienta: giornate di orientamento in cui vengono presentati tutti i corsi dell'Università di Bologna;

- Incontro con le matricole: all'inizio delle lezioni vengono organizzati incontri per fornire indicazioni sull'organizzazione e la didattica degli insegnamenti.
- Open Day: il corso organizza nel periodo gennaio-maggio una serie di incontri in cui fornisce informazioni dettagliate sulle modalità di accesso e sulle attività formative erogate. Gli studenti visitano i laboratori di ricerca del corso di studio.
- Seminari: il corso organizza dei seminari su tematiche specifiche (Android/Arduino) per studenti delle scuole superiori.

## Orientamento per gli iscritti

L'Ateneo mette a disposizione dei suoi studenti strumenti per affrontare al meglio l'esperienza universitaria e avere un supporto informativo e orientativo durante gli studi.

Oltre a servizi di tutorato, consulenza e tirocini organizza iniziative ed attività utili al tuo percorso.

Maggiori informazioni

## Orientamento per laureandi o laureati

L'Università di Bologna offre supporto a chi intende proseguire il percorso formativo oppure accedere al mondo del lavoro.

Maggiori informazioni

### vedi anche

- Materiale di orientamento per gli studenti delle scuole superiori

### Contatti

#### Servizio Orientamento

Come ti può aiutare
                    Scelta del corso di studio, inserimento nella vita universitaria anche con eventi di orientamento.

E-mail
campuscesena.orientamentourp@unibo.it

Telefono
+39 0547 338900
Orario telefonico

                            Lunedì
                            9-11:30
                          

                            Martedì
                            9-11:30
                          

                            Mercoledì
                            9-11:30
                          

                            Giovedì
                            13:30-15:30

Indirizzo
Via Montalti 69, Cesena
Orario apertura al pubblico

#### Tutor di Orientamento

Come ti può aiutare
                    Scelta più consapevole del percorso di studi, indicazioni sulle modalità per iscriverti.

Nome referente
                      Elvis Perlika

Sito web

Altre informazioni
Il Tutor riceve su appuntamento tramite email: elvis.perlika2@unibo.it
Live chat: Mercoledì dalle 18.00 alle 19.00 (al link nella sezione Sito Web)

#### Tutor del corso

Come ti può aiutare
                    Dalla scelta del corso all’orario delle lezioni, dalla compilazione del piano di studi agli esami o alle indicazioni per la tesi. Studia come te, può consigliarti su come organizzare gli studi.

Nome referente
                      Filippo Berveglieri

E-mail
campuscesena.tutorltisi@unibo.it

Altre informazioni
Riceve su appuntamento tramite e-mail.

#### Manager didattico

Come ti può aiutare
                    Segnalazioni su aspetti logistici e organizzativi relativamente allo svolgimento delle attività del corso, informazioni generali su ammissioni, esami, orari, piano di studi e laurea.

Nome referente
                      Enrica Zanelli

E-mail
campuscesena.tutorltisi@unibo.it

- Sosteniamo il diritto alla conoscenza