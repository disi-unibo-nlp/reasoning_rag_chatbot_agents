# Materiale di orientamento per gli studenti delle scuole superiori

## Laurea in Ingegneria e scienze informatiche

<!-- image -->

Ecco un po' di materiale informativo che può esserti utile per conoscere il corso.

- slide di presentazione;
- Ingegneria e Scienze Informatiche e Tecnologie dei Sistemi Informatici a confronto;
- risposte alle domande più frequenti;
- ulteriori approfondimenti.

Per qualsiasi dubbio puoi scriverci a orientamento@isi.polocesena.unibo.it.

- Sosteniamo il diritto alla conoscenza