# Esami e voto medio conseguito

Elenco degli insegnamenti del Corso con l'indicazione relativa al numero degli esami e al voto medio.

I dati sono relativi all'anno precedente e ogni voce accorpa eventuali articolazioni (moduli, sottogruppi per lettera, esami integrati). 
 Le idoneità non sono comprese nell'elenco.

| Insegnamento                                  |   N. Esami con voto |   Voto medio |
|-----------------------------------------------|---------------------|--------------|
| FISICA                                        |                 127 |           23 |
| RICERCA OPERATIVA                             |                 179 |           25 |
| SYSTEMS INTEGRATION                           |                   3 |           25 |
| ALGORITMI NUMERICI                            |                   1 |           18 |
| HIGH-PERFORMANCE COMPUTING                    |                  36 |           28 |
| INGEGNERIA DEL SOFTWARE                       |                 150 |           23 |
| PROGRAMMAZIONE DI SISTEMI MOBILE              |                  53 |           28 |
| MATEMATICA DISCRETA E PROBABILITÀ             |                 116 |           22 |
| ARCHITETTURE DEGLI ELABORATORI                |                 180 |           26 |
| PROGRAMMAZIONE                                |                 194 |           25 |
| FONDAMENTI DI ELABORAZIONE DI IMMAGINI        |                   3 |           24 |
| PROGRAMMAZIONE DI APPLICAZIONI DATA INTENSIVE |                  52 |           28 |
| BASI DI DATI                                  |                 127 |           24 |
| VISIONE ARTIFICIALE                           |                  67 |           25 |
| TECNOLOGIE WEB                                |                 151 |           25 |
| SISTEMI EMBEDDED E INTERNET-OF-THINGS         |                  80 |           28 |
| INFORMATICA E DIRITTO                         |                  73 |           27 |
| ANALISI MATEMATICA                            |                 164 |           24 |
| RETI DI TELECOMUNICAZIONE                     |                 227 |           25 |
| COMPUTER GRAPHICS                             |                  25 |           27 |
| METODI NUMERICI                               |                 137 |           25 |
| ALGEBRA E GEOMETRIA                           |                 169 |           24 |
| BASI DI DATI AVANZATE                         |                   3 |           27 |
| PROGRAMMAZIONE DI RETI                        |                 179 |           25 |
| SISTEMI OPERATIVI                             |                 165 |           26 |
| ALGORITMI E STRUTTURE DATI                    |                 155 |           25 |
| VIRTUALIZZAZIONE E INTEGRAZIONE DI SISTEMI    |                  29 |           27 |
| LABORATORIO DI BASI DI DATI                   |                   1 |           26 |
| PROGRAMMAZIONE AD OGGETTI                     |                 157 |           26 |
| CRITTOGRAFIA                                  |                  70 |           28 |

- Sosteniamo il diritto alla conoscenza