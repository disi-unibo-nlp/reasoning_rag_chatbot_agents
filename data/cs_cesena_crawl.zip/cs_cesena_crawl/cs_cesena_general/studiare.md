# Studiare

<!-- image -->

## Attività didattiche

- Insegnamenti: piano didattico
- Orario delle lezioni
- Frequenza delle lezioni
- Appelli d'esame
- Calendario didattico
- Compilare il piano di studi
- Cosa sono e come assolvere gli OFA
- Docenti
- Aule, laboratori e biblioteche
- Formazione obbligatoria su sicurezza e salute

<!-- image -->

## Tirocinio

- Tirocini curriculari in Scuole e Organizzazioni no profit
- Tirocini curriculari e in preparazione della prova finale
- Richiesta riconoscimento attività lavorativa o extra-universitaria in sostituzione del tirocinio
- Tirocini all'estero

<!-- image -->

## Prova finale

- Prova Finale: modalità e scadenze
- Redazione della tesi e voto finale
- Borse di studio per tesi all'estero

<!-- image -->

## Preparati al mondo del lavoro

- Idee sul futuro: i passi da compiere
- Imprenditorialità: dall'idea al progetto di startup
- Preparati per incontrare le aziende

### Come fare per

- Ottenere un certificato o un duplicato
- Trasferirsi ad altro Ateneo
- Gestire un infortunio
- Passaggio (opzione) al Corso di Nuovo Ordinamento
- Lasciare e riprendere gli studi
- Giustificativo per il datore di lavoro
- Sistema Bibliotecario di Ateneo - Informazioni e supporto da studente a studente tramite LiveChat su Teams
- Prolungare la durata degli studi - Studente a tempo parziale
- Ottenere lo status di studente-atleta
- Attivare una carriera alias
- Conciliare studio e lavoro
- Rinnovo del permesso di soggiorno
- Riconoscimento crediti
- Cambiare Corso

- Sosteniamo il diritto alla conoscenza