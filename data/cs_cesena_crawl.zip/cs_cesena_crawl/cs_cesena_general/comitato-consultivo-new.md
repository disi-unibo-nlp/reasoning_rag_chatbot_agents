# Comitato Consultivo

Il Comitato consultivo è istituito con la finalità di stabilire un contatto costante con il mondo della produzione, dei servizi e delle professioni, per raccogliere pareri e indirizzi sul progetto formativo del corso stesso e si riunisce almeno una volta all’anno.

È costituito da soggetti che negli ambiti delle imprese, del terzo settore, delle professioni, delle istituzioni pubbliche e private di formazione e ricerca, e della società civile, possano apportare un contributo significativo alle attività di formazione e di ricerca rilevanti per il Corso. Ne fa parte almeno un docente membro della Commissione AQ.

- Sosteniamo il diritto alla conoscenza