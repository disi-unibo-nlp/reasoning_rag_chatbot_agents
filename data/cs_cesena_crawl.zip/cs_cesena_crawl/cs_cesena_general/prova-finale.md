# Prova Finale: modalità e scadenze

La prova finale è l'ultimo esame svolto in conclusione del Corso di Laurea.

Per laurearsi lo studente deve aver conseguito tutti i crediti formativi previsti dal regolamento  didattico del Corso di Laurea, eccetto quelli relativi alla prova finale.

## Domanda di laurea

La domanda di laurea prevede il pagamento della tassa di laurea.

Se la domanda viene presentata oltre il termine ordinario ed entro la scadenza tardiva con mora è previsto il pagamento di un’indennità di mora.

La domanda di Laurea è valida per un solo anno accademico. Se lo studente si laurea in un anno accademico successivo dovrà ripresentare domanda di laurea e versare solo l'importo della marca da bollo.

<!-- image -->

Accedi a Studenti Online per presentare la domanda di laurea e rispetta alcune importanti scadenze.

Entro la scadenza dei requisiti richiesti per la laurea, lo studente deve:

1. Verificare che il proprio relatore abbia autorizzato l'ammissione all'esame

2. Avere sostenuto tutti gli esami previsti dal proprio piano di studi ed essere in regola con il pagamento delle tasse universitarie

3. Compilare il questionario online di Almalaurea

Ulteriori informazioni amministrative sono disponibili al seguente link:

http://www.unibo.it/it/didattica/iscrizioni-trasferimenti-e-laurea

UPLOAD DELL’ELABORATO FINALE SU STUDENTI ONLINE

Gli studenti laureandi devono caricare l¹elaborato completo di frontespizio, in formato PDF testuale e non protetto da password, su Studenti Online, entro la scadenze che trovate sotto.

-  Il contenuto del file e il livello di accesso in AMS tesi di Laurea devono essere stati concordati preventivamente con il relatore che li approverà successivamente al caricamento della tesi in SOL;

- Il file non dovrà superare i 30Mb.

-  Lo studente deve rispettare la scadenza per l'upload del proprio elaborato e ricevere l'approvazione del relatore.

- Solo dopo l'approvazione del relatore lo studente deve scaricare la dichiarazione di deposito, prodotta dal sistema in automatico, firmarla e inviare la scansione via mail bibliotecacesena.info@unibo.it alla Biblioteca, insieme alla scansione del proprio documento di identità (come da istruzioni nel Box Allegati), per le tesi il cui livello di accesso lo prevede. Solo con l’invio della dichiarazione di deposito si potrà procedere alla pubblicazione online del lavoro di tesi nell’archivio istituzionale dell’Ateneo AMS Tesi di Laurea, in base al livello di accesso prescelto e concordato con il relatore.

Redazione dell’elaborato

La redazione dell’elaborato dovrà essere standardizzata, con l’avvertenza che non verranno accettati elaborati/tesi redatti in modo difforme dalle seguenti prescrizioni:

- pagine di 32-35 righe, ciascuna di 65-70 caratteri di tipo prestabilito (Times, Courier o Helvetica);

- frontespizio conforme al fac-simile (vedi box allegati);

- figure e tavole in formato UNI (A4 e A3);

- formato PDF.

La conformità dell’elaborato alle regole suddette deve essere verificata anche dal Relatore.

Calendario a.a. 2024/2025

|  Scadenza presentazione domanda di laurea    |  Scadenza domanda di laurea tardiva (con indennità di mora)    |  Scadenza requisiti di carriera    |  Scadenza upload tesi di laurea da parte studente    |  Approvazione tesi da parte del relatore    |    Consegna dichiarazione di deposito    |  Appello di laurea     |
|----------------------------------------------|----------------------------------------------------------------|------------------------------------|------------------------------------------------------|---------------------------------------------|------------------------------------------|------------------------|
| 05/06/2025                                   | 19/06/2025                                                     | 26/06/2025                         | 03/07/2025                                           | 07/07/2025                                  | 10/07/2025                               | 17/07/2025             |
| 20/08/2025                                   | 04/09/2025                                                     | 10/09/2025                         | 17/09/2025                                           | 22/09/2025                                  | 25/09/2025                               | 02/10/2025             |
| 17/10/2025                                   | 31/10/2025                                                     | 07/11/2025                         | 14/11/2025                                           | 18/11/2025                                  | 20/11/2025                               | 27/11/2025             |
| 29/01/2026                                   | 12/02/2026                                                     | 19/02/2026                         | 26/02/2026                                           | 02/03/2026                                  | 05/03/2026                               | 13/03/2026             |

N.B. Tutte le informazioni sulle riprese fotografiche e video durante le sedute di laurea qui

### In evidenza

### allegati

- Linee guida tesi 8615.pdf

[
          .pdf
          37Kb
          ]
- il-diritto-autore-sulla-tesi-di-laurea.pdf

[
          .pdf
          159Kb
          ]
- Istruzioni AMS Laurea

[
          .pdf
          122Kb
          ]
- Riprese fotografiche e video durante le sedute di laurea

### Contatti

#### Servizio didattico

Come ti può aiutare
                    Informazioni sull'orario delle lezioni, supporto per l’iscrizione agli appelli d’esame, compilazione del piano degli studi, riconoscimento dei crediti nel caso di trasferimenti o passaggi di corso e organizzazione delle sedute di laurea.

E-mail
campuscesena.didattica.isa@unibo.it

Telefono
+39 0547338300
Orario telefonico

Altre informazioni
Puoi contattarci via e-mail e via Teams. Scrivi una e-mail per informazioni o per un collegamento diretto tramite l'app Teams. Riceverai una e-mail con data, ora e link a cui collegarti dopo aver scaricato l'app.

#### Segreteria studenti

Come ti può aiutare
                    Iscrizioni, cambi di corso, trasferimenti da e verso altri atenei, laurea, diploma supplement e altre procedure.

Nome referente
                      Stefano Macrelli

Sportello virtuale

E-mail
segcesena@unibo.it

Indirizzo
Palazzo Urbinati - Via Montalti 69 - 47521 Cesena FC
Orario apertura al pubblico

                            Mercoledì
                            9-12

Altre informazioni
Prendi un appuntamento via e-mail per la consegna dei documenti oppure inviali per posta.

- Sosteniamo il diritto alla conoscenza