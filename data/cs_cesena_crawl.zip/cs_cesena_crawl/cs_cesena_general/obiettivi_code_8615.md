# Obiettivi formativi

Se devi iscriverti fai riferimento al codice 6673.
 Se sei già iscritto puoi verificare il codice del tuo corso su Studenti Online.

- Codice 6673
- Codice 8615

8615 - Ingegneria e scienze informatiche

Il raggiungimento degli obiettivi qualificanti specificati dal decreto sulle classi è ottenuto attraverso un percorso didattico finalizzato alla formazione di laureati contraddistinti sia da una solida preparazione teorica, tecnologica e metodologica, sia da peculiari competenze operative derivanti da mirate attività progettuali, di gruppo o individuali, che costituiscono parte integrante dell'iter formativo. A questo scopo lo studente è guidato nel processo di apprendimento delle problematiche, dei modelli di riferimento e dei metodi che contraddistinguono la modellazione e la progettazione dei moderni sistemi di elaborazione dell'informazione, nonché delle tecnologie più avanzate disponibili per una loro concreta applicazione.

Particolare enfasi è rivolta all'inquadramento organico dei principi fondazionali, all'esemplificazione degli approcci metodologici, alla presentazione di ambienti e strumenti che supportano, in una visione sistemistica, la progettazione di software, di sistemi operativi, sistemi informativi, reti di calcolatori, infrastrutture web, architetture computazionali e infrastrutture virtuali dispiegati in cloud.
Le competenze specifiche nel settore sono integrate da solide basi fisico-matematiche e da conoscenze interdisciplinari riguardanti altri ambiti caratterizzanti. Completa la formazione del laureato la conoscenza della lingua inglese a livello B2. Possono essere previste sia l'acquisizione delle quattro abilità linguistiche (lettura, scrittura, ascolto, e dialogo) sia la frequenza vincolata delle lezioni, secondo criteri che verranno specificati in itinere dal corso di studi, in coerenza alle prescrizioni degli Organi accademici.

Complessivamente, il corso di laurea fornisce le competenze teorico-pratiche relative alle principali aree dell'informatica. Rappresentano specifici obiettivi formativi l'apprendimento dei principi dell'ingegneria del software, delle tecniche di programmazione e di progettazione dei sistemi informatici, la conoscenza delle principali tecnologie hardware e software, dei sistemi operativi, dei sistemi di rete e dei sistemi web. A queste conoscenze di base si aggiungono poi conoscenze professionalizzanti in specifici settori dell'informatica che possano permettere al laureato l'ingresso diretto nel mondo del lavoro, tra i quali i sistemi mobile, i sistemi embedded e IoT, le tecniche di virtualizzazione e le tecniche di machine learning per applicazioni di AI.
Il raggiungimento di questi obiettivi richiede di acquisire preventivamente una cultura scientifica di base nonché un metodo di analisi e di studio scientifici che permettano, allo studente prima e al laureato poi, di costruire autonomamente nuove conoscenze al fine di adeguarsi all'evoluzione della disciplina e di utilizzare metodi innovativi e attrezzature complesse.

Il laureato possiede:
- un ampio spettro di conoscenze e competenze nei vari settori dell'informatica mirate al loro utilizzo nella progettazione, sviluppo e gestione di reti e sistemi informatici, indipendentemente dallo specifico dominio applicativo;
- adeguata padronanza degli strumenti matematici necessari per la modellazione formale, l'analisi, la valutazione, la progettazione e la realizzazione di sistemi;
- capacità di assimilare con un certo grado di autonomia alcuni temi d'avanguardia nel proprio campo di studi;
- capacità di ideare e sostenere argomentazioni sia nell'ambito del lavoro di gruppo, sia nell'ambito del lavoro individuale;
- capacità di raccogliere ed interpretare i dati sperimentali al fine di valutare l'efficacia e l'efficienza di sistemi informatici;
- capacità di utilizzare efficacemente, in forma scritta e orale, la lingua inglese, in aggiunta all'italiano, sia nell'ambito specifico di competenza sia per lo scambio di informazioni generali;
- capacità di effettuare ricerche bibliografiche anche avvalendosi di banche dati e di reti informatiche;
- competenze necessarie per intraprendere studi successivi con un alto grado di autonomia.

Per dotare il laureato delle caratteristiche suddette, il corso di studi prevede:
- attività formative finalizzate ad acquisire conoscenze matematiche di base, oltre a conoscenze fondamentali sulle principali aree dell'informatica (tra le quali linguaggi di programmazione, algoritmi, sistemi operativi, basi di dati e sistemi informativi, reti di calcolatori, sistemi web, tecniche di virtualizzazione, tecniche di machine learning per applicazioni di AI, ingegneria del software);
- attività progettuali e di laboratorio mirate ad acquisire la conoscenza dei metodi di progettazione e programmazione;
- attività per fornire conoscenze di base della lingua inglese.

### Archivio

- Sosteniamo il diritto alla conoscenza