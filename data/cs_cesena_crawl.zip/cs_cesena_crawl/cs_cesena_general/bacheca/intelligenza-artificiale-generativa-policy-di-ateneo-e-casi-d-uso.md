# Intelligenza artificiale generativa: policy di Ateneo e casi d'uso

Linee guida, casi concreti e indicazioni operative per usare la GenAI in modo etico e consapevole nel tuo percorso di studi.

Pubblicato il
        09 gennaio 2025

L'Università di Bologna ha adottato una policy per promuovere un uso etico e responsabile dell'Intelligenza Artificiale Generativa (GenAI) nelle attività didattiche e di ricerca. Questa iniziativa mira a integrare le tecnologie avanzate nel nostro Ateneo, garantendo al contempo il rispetto della qualità, dell'etica e dell'integrità accademica.

## Perché è importante conoscere la policy?

- Indicazioni operative
La policy offre linee guida su come utilizzare la GenAI nelle attività accademiche, assicurando un approccio consapevole e responsabile.
- Casi d'uso
Sono presentati esempi pratici che illustrano l'applicazione della GenAI in diversi contesti, facilitando la comprensione delle sue potenzialità e dei suoi limiti.
- Supporto all'apprendimento e alla ricerca
Conoscere la policy aiuta a sfruttare al meglio le opportunità offerte dalla GenAI.

Per maggiori dettagli, visita la pagina dedicata sul sito dell'Università di Bologna.

## Vuoi approfondire?

Partecipa al ciclo di incontri, in presenza e online, promossi dall'Ateneo "Per un uso etico e responsabile dell’AI generativa tra conoscenza e applicazioni".

Consulta gli appuntamenti e iscriviti online

- Sosteniamo il diritto alla conoscenza