# Vuoi iscriverti all’università ma lavori oppure pratichi sport agonistico: le agevolazioni per far bene tutto

Il 25 febbraio ne parleremo durante la Giornata dell’Orientamento.

Pubblicato il
        18 febbraio 2025

Conciliare studio e lavoro oppure studio e sport a livello agonistico richiede tanta volontà e organizzazione, ma sai che puoi contare su servizi e agevolazioni fatte apposta per te? Questi gli eventi da segnare:

15:30 – 16 Come conciliare lavoro e studio

15:30 – 16 Come conciliare carriera sportiva e studio

#### Come partecipare

La Giornata dell’Orientamento è online, la partecipazione è gratuita con iscrizione obbligatoria.

Iscriviti entro il 24 febbraio.

- Sosteniamo il diritto alla conoscenza