# Idoneità linguistica.

Scopri quando puoi sostenerla: consulta il calendario delle prossime date e delle iscrizioni.

Pubblicato il
        26 maggio 2025

### Per informazioni:

- Calendario

- Sosteniamo il diritto alla conoscenza