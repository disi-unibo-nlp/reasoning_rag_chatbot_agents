# Incontra il corso alla Giornata dell'Orientamento online 2025

Oltre 500 eventi tra le 9:30 e le 17:00 per conoscere i corsi. Iscriviti ora per accedere in anteprima al programma e scegliere quelli che ti interessano.

25 febbraio 2025 dalle 09:30 alle 17:00

Ms Teams -
                  Online

L’occasione giusta per conoscere attraverso l’esperienza. Durante l’evento potrai:

- conoscere i 118 Corsi di laurea e laurea magistrale a ciclo unico
- incontrare studenti e studentesse del corso
- saperne di più sulle modalità di accesso
- assistere magari a una vera lezione per conoscere da vicino le discipline che studierai
- conoscere i servizi che ti supporteranno nel tuo percorso e le opportunità che renderanno unica la tua esperienza universitaria

Iscriviti online ed entra in anteprima per consultare il programma e scegliere gli appuntamenti a cui partecipare.

- Sosteniamo il diritto alla conoscenza