# Chiusura delle sedi venerdì 18 aprile 2025

In occasione delle Festività Pasquali

Pubblicato il
        17 aprile 2025

## Venerdì 18 aprile 2025 saremo chiusi.

## La nostra sede riaprirà martedì 22 aprile 2025.

- Sosteniamo il diritto alla conoscenza