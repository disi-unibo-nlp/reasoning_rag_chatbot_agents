# Archivio notizie

### Idoneità linguistica.

Scopri quando puoi sostenerla: consulta il calendario delle prossime date e delle iscrizioni.

Pubblicato il
                            26 maggio 2025

### Hai un’idea imprenditoriale? Hai un’idea da sviluppare e ti piacerebbe capire come trasformarla in un’impresa?

ISIHUB Romagna ti offre un percorso formativo gratuito per supportarti nella crescita e accompagnarti in ogni fase de tuo progetto !

Pubblicato il
                            19 maggio 2025

### Call for Players 2025

Non hai avuto modo di partecipare all'evento evento concluso ad aprile 2025? Non temere, puoi ancora contribuire a creare una startup di successo. Scopri come fare.

Pubblicato il
                            13 maggio 2025

### Premio Tesi di Laurea “Ingenio al Femminile”

Il Consiglio Nazionale degli Ingegneri bandisce un concorso a premi riservato a donne ingegnere in tema  di "Intelligenza artificiale per le nuove sfide del 2050". Scadenza: 30 giugno.

Pubblicato il
                            13 maggio 2025

### Una Europa Student Visual Art Contest 2025

Sei pronto a mostrare la tua creatività? Partecipa al concorso per esprimere il tuo talento attraverso un'opera che rappresenti il tema dell'Alleanza tra università. Scadenza: 11 maggio.

Pubblicato il
                            28 aprile 2025

### Referendum popolari abrogativi - voto fuorisede

Studi in un comune di una provincia diversa da quella di iscrizione elettorale? Puoi chiedere di votare nel tuo comune di domicilio temporaneo.

Pubblicato il
                            28 aprile 2025

### Chiusura delle sedi venerdì 18 aprile 2025

In occasione delle Festività Pasquali

Pubblicato il
                            17 aprile 2025

### Tornano anche nel 2025 i Summer Camp “Ragazze Digitali”

Ser.In.Ar., in collaborazione con Art-ER e con il Dipartimento di Informatica – Scienza e Ingegneria dell’Università di Bologna, realizza anche quest’anno i 5 Summer Camp “Ragazze Digitali”.

Pubblicato il
                            17 aprile 2025

### Borse di studio Studentesse STEM

Legacoop Romagna bandisce 3 borse di studio per studentesse STEM per sostenere la componente femminile nei percorsi di laurea in ambito scientifico, ingegneristico e matematico. Scadenza: 28 aprile.

Pubblicato il
                            03 aprile 2025

### Campionati Europei Universitari di Basket 2025

Unisciti ai Basket Heroes, la squadra di volontarie e volontari che dal 6 al 13 luglio Bologna potrà partecipare attivamente ai campionati. Candidati online.

Pubblicato il
                            29 marzo 2025

### Diventa rappresentante della comunità studentesca. Candidati entro l'8 aprile

Il 14 e 15 maggio si vota per le rappresentanze studentesche negli Organi di Ateneo. Entra in gioco e diventa portavoce delle esigenze e dei progetti della nostra comunità studentesca.

Pubblicato il
                            24 marzo 2025

### Bando Erasmus+ Mobilità per Tirocinio a.a. 2025-2026

Riunione informativa per presentazione della candidatura. Lunedì 24 marzo ore 12.00.

Pubblicato il
                            17 marzo 2025

- 1
- 2
- 3
- Successivi 12 elementi

- Sosteniamo il diritto alla conoscenza