# Per un cv efficace

Vieni al seminario a cura del Servizio Orientamento al lavoro e Placement

13 maggio 2025 dalle 12:00 alle 14:00

Aula 2.5 del Campus di Cesena - via dell'Università, 50 -
                  Evento in presenza

### Per informazioni:

- Locandina

[
          .png
          911Kb
          ]

- Sosteniamo il diritto alla conoscenza