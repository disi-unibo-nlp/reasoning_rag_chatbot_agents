# Ripassa la matematica con i webinar di AlmaMathematica

Partecipa ai percorsi online gratuiti: docenti o tutor ti aiuteranno a risolve quiz a risposta multipla sugli argomenti matematici presenti nei diversi TOLC. Scopri il calendario dei webinar.

Pubblicato il
        22 gennaio 2025

### Per informazioni:

- Date e informazioni

- Sosteniamo il diritto alla conoscenza