# Incontro Outgoing bando Erasmus studio 2025-2026

Riunione via Teams martedì 14 gennaio alle ore 13:00

Pubblicato il
        09 gennaio 2025

E' stato pubblicato il Bando Erasmus Mobilità per Studio 2025-2026: https://www.unibo.it/it/internazionale/studiare-all-estero/erasmus/come-partecipare ,  che offre la possibilità di ottenere una borsa di studio per trascorrere parte del proprio percorso universitario in un altro paese europeo o in alcuni paesi non europei.

Martedì 14 gennaio alle ore 13:00 si terrà una riunione via Teams, nella quale saranno dati i dettagli per presentare la candidatura. In basso trovi il link a cui collegarti, nel giorno e ora indicati, attraverso il tuo account nome.cognome@studio.unibo.it

L’incontro si terrà in Italiano. Ti informiamo che il 16 gennaio alle ore 12:00 verrà organizzato un analogo incontro in lingua inglese, per quest’ultima riunione il giorno stesso verrà inviata al tuo account @studio.unibo.it una e-mail con il link per partecipare.

Le prime fasi del CALENDARIO DELLE SCADENZE - Bando Erasmus+ Mobilità per Studio AA 2025/2026 sono:

8 gennaio 2025: Pubblicazione bando e apertura della presentazione delle candidature.

Dal 8 gennaio 2025 ore 13.00 al 17 gennaio 2025 entro le ore 13.00: Apertura delle iscrizioni per le prove di accertamento linguistico tramite l’applicativo online AlmaRM. I posti sono in numero limitato

Dal 22 gennaio 2025 al 4 febbraio 2025: Periodo di svolgimento delle prove di accertamento linguistico presso il CLA (sede di Bologna e sedi della Romagna)

6 febbraio 2025, ore 13.00 Scadenza per la presentazione della candidatura

Staff dell’Ufficio Tirocini e Relazioni Internazionali Cesena -Servizio Relazioni Internazionali(e-mail campuscesena.uri@unibo.it )

Microsoft Teams Serve aiuto?

Partecipa alla riunione ora

- Sosteniamo il diritto alla conoscenza