# Bando Erasmus+ Mobilità per Tirocinio a.a. 2025-2026

Riunione informativa per presentazione della candidatura. Lunedì 24 marzo ore 12.00.

Pubblicato il
        17 marzo 2025

Lunedì 24 marzo ore 12:00, insieme ai Professori delegati all’Internazionalizzazione per i corsi di studio di Ingegneria, Scienze, Architettura - sede di Cesena, è stata organizzata una riunione informativa via Teams, nella quale verranno dati i dettagli per presentare la propria candidatura al bando Erasmus+ Mobilità per Tirocinio 2025/26:

https://www.unibo.it/it/internazionale/tirocini-estero/erasmus-mobilita-per-tirocinio/erasmus-mobilita-tirocinio-come-partecipare/erasmus-mobilita-tirocinio-come-partecipare

Il programma permette di svolgere un tirocinio presso un’impresa o altra organizzazione in uno dei paesi europei o in alcuni paesi non europei partecipanti al Programma  e prevede l'erogazione di un contributo finanziario per coprire parte delle spese sostenute dagli studenti durante il periodo di tirocinio.

In basso trovate il link a cui collegarvi, nel giorno e ora indicati, attraverso il vostro account nome.cognome@studio.unibo.it

L’incontro si terrà in italiano. Infine il 25 marzo alle ore 12, verrà organizzato un analogo incontro in lingua inglese, per quest’ultima riunione il giorno stesso verrà inviata al tuo account @studio.unibo.it una e-mail con il link per partecipare.

Microsoft Teams Serve aiuto?

Partecipa alla riunione ora

- Sosteniamo il diritto alla conoscenza