# Insegnamenti: piano didattico

## Piani disponibili nell'A.A. 2025/2026

Guarda il piano didattico che ti interessa, in base all'anno in cui ti sei iscritto.

- Codice 6673
- Codice 8615

6673 - Ingegneria e scienze informatiche

- Piano didattico per studenti immatricolati nell'a.a. 2025-26

- Sosteniamo il diritto alla conoscenza