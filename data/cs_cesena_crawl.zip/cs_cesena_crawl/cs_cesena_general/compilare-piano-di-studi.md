# Compilare il piano di studi

Informazioni per preparare e presentare il piano di studi

## Che cos'è il piano di studi

Il piano di studi è l'insieme di tutti gli esami che lo studente deve sostenere per potersi laureare. Alcuni esami sono obbligatori, mentre altri sono a scelta dello studente.

Lo studente può sostenere soltanto gli esami già presenti nel proprio piano di studi.

Possono presentare il piano di studi via web gli studenti regolarmente iscritti all'anno accademico in corso e fuori corso; gli studenti: 
- del PERCORSO LUNGO/FLESSIBILE
- appartenenti a CORSI DI LAUREA DISATTIVATI
- che riscontrano problemi di carattere informatico
- che intendono scegliere insegnamenti attivati presso Corsi di Studio a NUMERO PROGRAMMATO
possono compilare il modulo inserito in "Allegato" e inviarlo via e-mail alla Segreteria Studenti dalla casella di posta istituzionale all'indirizzo segcesena@unibo.it.

## Periodi di presentazione del piano di studi

Sono previste nell'A.A. 2024/2025 due aperture di piani web.

Primo periodo: 7 ottobre 2024 – 10 novembre 2024
Secondo periodo: 10 febbraio 2025 - 7 marzo 2025

Nel periodo di apertura dei piani web lo studente potrà compilare e modificare il proprio piano di studi senza limitazioni.

Anche se il piano di studi viene presentato, potrà essere recuperato, modificato e presentato nuovamente entro la scadenza. 
Pertanto tutti i piani compilati prima della data di inizio così come quelli inoltrati o modificati dopo la data di scadenza non saranno ritenuti validi. 

Attenzione! Dopo aver effettuato le scelte lo studente deve cliccare sul pulsante "Salva" affinché il proprio piano di studi possa essere correttamente presentato.

E' fortemente consigliato stampare dal web il piano di studi compilato.

Accesso a StudentiOnLine

La compilazione e la presentazione del proprio piano di studi avviene accedendo al servizio Studenti Online con le proprie credenziali d’Ateneo. Il Servizio è attivo solo nei periodi in cui è consentita la presentazione.

## Chi deve presentare il piano di studi

Studenti iscritti al terzo anno IN CORSO:

- è obbligatorio effettuare la scelta di 12 cfu tra gli insegnamenti opzionali di seguito elencati:

|    Codice  |  Denominazione insegnamento            |    CFU  |
|------------|----------------------------------------|---------|
|     70090  | COMPUTER GRAPHICS                      |      6  |
|     84339  | BASI DI DATI AVANZATE                  |      6  |
|     70227  | INFORMATICA E DIRITTO                  |      6  |
|     77780  | SISTEMI EMBEDDED E INTERNET OF THINGS  |      6  |
|     72787  | PROGRAMMAZIONE DI SISTEMI MOBILE       |      6  |
|     72796  | PROGRAMMAZIONE DI APPL. DATA INTENSIVE |      6  |
|     17634  | VISIONE ARTIFICIALE                    |      6  |

- e 12 cfu a libera scelta tra gli insegnamenti opzionali sopraelencati, tutti gli insegnamenti attivi in Ateneo e quelli riportati di seguito:

|    Codice  |  Denominazione insegnamento                 |    CFU  |
|------------|---------------------------------------------|---------|
|    14015   | CRITTOGRAFIA                                |     6   |
|     72778  | HIGH-PERFORMANCE COMPUTING                  |      6  |
|     96642  | VIRTUALIZZAZIONE E INTEGRAZIONE DEI SISTEMI |      6  |

Prova finale

Inoltre è obbligatorio, per poter chiudere correttamente il piano di studi, scegliere fin da ora come si vorrà svolgere la prova finale. 
La prova finale è così regolata:

- GRUPPO A: PROVA FINALE 6 cfu

- GRUPPO B: PROVA FINALE 3 cfu + un’altra attività da massimo 3 cfu fra Preparazione prova finale all’estero o Tirocinio all'estero in preparazione della prova finale o Tirocinio in preparazione della prova finale.

Questa scelta non è vincolante e potrà essere cambiata in qualsiasi momento, anche con una comunicazione dall’email istituzionale alla segreteria studenti segcesena@unibo.it, prima di intraprendere la preparazione alla prova finale.

### Allegato

- Modulo 8615 scelte

[
          .pdf
          37Kb
          ]

### Contatti

#### Servizio didattico

Come ti può aiutare
                    Informazioni sull'orario delle lezioni, supporto per l’iscrizione agli appelli d’esame, compilazione del piano degli studi, riconoscimento dei crediti nel caso di trasferimenti o passaggi di corso e organizzazione delle sedute di laurea.

E-mail
campuscesena.didattica.isa@unibo.it

Telefono
+39 0547338300
Orario telefonico

Altre informazioni
Puoi contattarci via e-mail e via Teams. Scrivi una e-mail per informazioni o per un collegamento diretto tramite l'app Teams. Riceverai una e-mail con data, ora e link a cui collegarti dopo aver scaricato l'app.

#### Segreteria studenti

Come ti può aiutare
                    Iscrizioni, cambi di corso, trasferimenti da e verso altri atenei, laurea, diploma supplement e altre procedure.

Nome referente
                      Stefano Macrelli

Sportello virtuale

E-mail
segcesena@unibo.it

Indirizzo
Palazzo Urbinati - Via Montalti 69 - 47521 Cesena FC
Orario apertura al pubblico

                            Mercoledì
                            9-12

Altre informazioni
Prendi un appuntamento via e-mail per la consegna dei documenti oppure inviali per posta.

- Sosteniamo il diritto alla conoscenza