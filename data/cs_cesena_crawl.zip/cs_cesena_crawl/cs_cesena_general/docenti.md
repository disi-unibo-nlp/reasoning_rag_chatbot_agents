# Docenti

Foto non disponibile

## Ciro Barbone

Professore a contratto

Vai al sito del docente

<!-- image -->

## Andrea Bonfiglioli

Professore ordinario

Vai al sito del docente

<!-- image -->

## Franco Callegati

Professore ordinario

Vai al sito del docente

<!-- image -->

## Raffaele Cappelli

Professore associato

Vai al sito del docente

<!-- image -->

## Antonella Carbonaro

Professoressa associata confermata

Vai al sito del docente

### Ultimo avviso

Al Campus di Cesena la finalissima e le premiazioni delle Olimpiadi di Problem Solving - edizione 2025

Pubblicato il 2025-04-15 10:58:32

<!-- image -->

## Fabrizio Caselli

Professore ordinario

Vai al sito del docente

<!-- image -->

## Eleonora Cinti

Professoressa associata

Vai al sito del docente

<!-- image -->

## Luisa Dall'Acqua

Professoressa a contratto

Vai al sito del docente

<!-- image -->

## Giovanni Delnevo

Ricercatore a tempo determinato tipo a) (junior)

Vai al sito del docente

<!-- image -->

## Matteo Ferrara

Professore associato

Vai al sito del docente

<!-- image -->

## Stefano Ferretti

Professore ordinario

Vai al sito del docente

### Ultimo avviso

Tesi di Laurea

Pubblicato il 2024-10-01 11:10:15

Foto non disponibile

## Enrico Fiumana

Professore a contratto

Vai al sito del docente

<!-- image -->

## Annalisa Franco

Professoressa associata

Vai al sito del docente

<!-- image -->

## Cristiano Frattagli

Professore a contratto

Vai al sito del docente

<!-- image -->

## Vittorio Ghini

Professore associato confermato

Vai al sito del docente

<!-- image -->

## Roberto Girau

Ricercatore a tempo determinato tipo b) (senior)

Vai al sito del docente

<!-- image -->

## Matteo Golfarelli

Professore ordinario

Vai al sito del docente

<!-- image -->

## Luigi Guiducci

Professore associato

Vai al sito del docente

<!-- image -->

## Alessandro Hill

Ricercatore a tempo determinato tipo a) (junior)

Vai al sito del docente

Foto non disponibile

## Damiana Lazzaro

Professoressa associata

Vai al sito del docente

<!-- image -->

## Alessandra Lumini

Professoressa associata

Vai al sito del docente

<!-- image -->

## Davide Maltoni

Professore ordinario

Vai al sito del docente

<!-- image -->

## Vittorio Maniezzo

Professore ordinario

Vai al sito del docente

### Ultimo avviso

Matheuristics, Algorithms and Implementations

Pubblicato il 2021-03-02 09:52:31

Foto non disponibile

## Luciano Margara

Professore ordinario

Vai al sito del docente

### Ultimo avviso

Tirocini in azienda

Pubblicato il 2013-11-04 18:35:41

<!-- image -->

## Moreno Marzolla

Professore associato

Vai al sito del docente

<!-- image -->

## Silvia Mirri

Professoressa ordinaria

Vai al sito del docente

<!-- image -->

## Luca Moci

Professore ordinario

Vai al sito del docente

<!-- image -->

## Gianluca Moro

Professore associato

Vai al sito del docente

### Ultimo avviso

Dow Jones Prediction and Trading with Deep learning

Pubblicato il 2018-06-02 03:41:16

Foto non disponibile

## Lorenzo Pellegrini

Ricercatore a tempo determinato tipo a) (junior)

Vai al sito del docente

<!-- image -->

## Danilo Pianini

Ricercatore a tempo determinato tipo b) (senior)

Vai al sito del docente

<!-- image -->

## Andrea Piroddi

Professore a contratto

Vai al sito del docente

<!-- image -->

## Catia Prandi

Professoressa associata

Vai al sito del docente

<!-- image -->

## Mirko Ravaioli

Professore a contratto

Vai al sito del docente

<!-- image -->

## Alessandro Ricci

Professore associato

Vai al sito del docente

### Ultimo avviso

Esami -- Data via email

Pubblicato il 2024-08-30 20:48:02

<!-- image -->

## Stefano Rizzi

Professore ordinario

Vai al sito del docente

<!-- image -->

## Paola Salomoni

Professoressa ordinaria

Vai al sito del docente

<!-- image -->

## Mirko Viroli

Professore ordinario

Vai al sito del docente

Il nome inserito non è presente nell'elenco.

- Sosteniamo il diritto alla conoscenza