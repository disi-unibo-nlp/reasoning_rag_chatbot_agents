# Opportunità

<!-- image -->

## Borse di studio e agevolazioni

- ER.GO: diritto agli studi
- Borse di studio e agevolazioni
- Borse di studio, premi e altre opportunità
- Agevolazioni per gli studenti internazionali
- Alloggi e residenze
- Muoversi in città: agevolazioni e sostenibilità per la comunità Unibo

<!-- image -->

## Esperienze all'estero

- Overseas
- Tirocini all'estero
- Borse di studio per tesi all'estero
- Tutte le opportunità

<!-- image -->

## Dopo la laurea

- Laurea Magistrale in Ingegneria e Scienze Informatiche
- Prospettive
- Prepararti al mondo del lavoro
- Hai un'idea? Trasformala in progetto d'impresa
- Offerte di lavoro

<!-- image -->

## Studenti e città

- Mense e punti di ristoro
- Trasporti e mobilità
- Vivere la città
- Associazioni e cooperative studentesche

### Servizi di Ateneo

- Garante degli studenti
- WIFI
- Assicurazione per gli studenti
- Assistenza sanitaria
- CLA-Centro Linguistico di Ateneo
- CUSB-Centro Universitario Sportivo Bologna
- SBA-Sistema Bibliotecario d'Ateneo
- Servizi per gli studenti con disabilità e con DSA
- Associazione Almae Matris Alumni
- Sportello universitario contro la violenza di genere
- Tirocini post laurea
- Servizio di Aiuto Psicologico a Giovani Adulti (SAP)
- Consigliera di Fiducia: un aiuto in caso di discriminazioni, molestie sessuali e psicologiche
- SMA- Sistema Museale d'Ateneo

- Sosteniamo il diritto alla conoscenza