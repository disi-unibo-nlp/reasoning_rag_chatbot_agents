# home page

<!-- image -->

## Progettare l’era digitale

Competenze per progettare e sviluppare sistemi e applicazioni software per le infrastrutture digitali del presente e del futuro.

- Sede didattica

                                    
                                        Cesena
- Lingua

                                    
                                        Italiano
- Classe di corso
                            
                            
                                L-8 R - INGEGNERIA DELL'INFORMAZIONE
L-31 R - SCIENZE E TECNOLOGIE INFORMATICHE
- Coordina il corso


                                        Franco Callegati
- Tipo di accesso

                                    
                                        Numero programmato locale - TOLC-I
- Dipartimento

Informatica - Scienza e Ingegneria - DISI
- Insegnamenti

Il piano didattico
- Stato

                                
                                    L’attivazione del corso di studio è subordinata alla conclusione dell’iter ministeriale.

## Cosa ti serve oggi

- Orario delle lezioni
- Insegnamenti: piano didattico
- Appelli d'esame
- Elenco Docenti
- Verso il mondo del lavoro
- Metodo di studio

## Cosa devi sapere

News, eventi e memo per il tuo percorso di studi

### Tornano anche nel 2025 i Summer Camp “Ragazze Digitali”

Ser.In.Ar., in collaborazione con Art-ER e con il Dipartimento di Informatica – Scienza e Ingegneria dell’Università di Bologna, realizza anche quest’anno i 5 Summer Camp “Ragazze Digitali”.

### Idoneità linguistica.

Scopri quando puoi sostenerla: consulta il calendario delle prossime date e delle iscrizioni.

### Premio Tesi di Laurea “Ingenio al Femminile”

Il Consiglio Nazionale degli Ingegneri bandisce un concorso a premi riservato a donne ingegnere in tema  di "Intelligenza artificiale per le nuove sfide del 2050". Scadenza: 30 giugno.

11
giu

ore 15:00

### Incontra il corso

In presenza

Mi interessa se: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando di concorso per l’assegnazione di contributi a favore di studenti con disabilità e a favore di studenti con disturbi dell’apprendimento iscritti all’A.A. 2024/2025

Scadenza: 17 giu 2025, 17:00

<!-- image -->

## Summer e Winter School

Approfondisci i tuoi interessi e migliora le tue competenze, allarga i tuoi orizzonti con esperienze interdisciplinari e culturali.

Scopri i corsi

## Dai spazio a interessi e passioni

- Competenze trasversali

Aggiungi valore al tuo curriculum e facilita le tue relazioni, anche sul lavoro.
- Esperienze all'estero

Dai al tuo percorso universitario una dimensione internazionale, dallo studio al tirocinio.
- Sport e cultura

Opportunità e iniziative per arricchire il tuo tempo libero con esperienze sportive e culturali.
- Biblioteche e risorse digitali

Un patrimonio fatto di scienza, arte, storia a tua disposizione gratuitamente, anche online.

- Sosteniamo il diritto alla conoscenza