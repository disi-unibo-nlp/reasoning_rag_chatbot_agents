# Cosa dicono i nostri studenti

<!-- image -->

Un ambiente stimolante, dei professori costantemente disponibili e un'associazione studentesca sempre attiva, hanno cambiato radicalmente il mio modo di concepire l’università.

Luca Giulianini, studente

<!-- image -->

Trovo che l'unione di un corso di Ingegneria con un corso di scienze, sia il modo migliore per studiare l'informatica; unendo la teoria alla pratica si riesce ad apprendere molto di più un argomento. Quindi si ottiene sia una formazione per continuare un eventuale corso magistrale, sia una buona base per intraprendere un percorso lavorativo.

Greta Bucciarelli, studentessa

<!-- image -->

Questo corso è il mix perfetto fra ingegneria e scienze, e consente di studiare l'informatica come si fa nel resto d'Europa, infatti ho partecipato al programma Erasmus e sono stato in Danimarca dove mi sono trovato molto bene ed i docenti del luogo mi hanno chiesto di rimanere in contatto per future collaborazioni.

Shapour Nemati, studente

## Laurea in Ingegneria e Scienze informatiche - Cosa dicono gli studenti

<!-- image -->

- Sosteniamo il diritto alla conoscenza