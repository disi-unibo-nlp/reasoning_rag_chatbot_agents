# Commissione di gestione AQ e altre

Per svolgere alcune delle sue funzioni il Consiglio di Corso si avvale di commissioni costituite da docenti del corso. Di seguito un elenco delle commissioni con le rispettive funzioni e contatti.

<!-- image -->

## Commissione di gestione AQ

La Commissione di gestione Assicurazione di Qualità del Corso ha il compito di supportare il Coordinatore nel presidio delle procedure di assicurazione di qualità e nella diffusione della cultura delle qualità.

A questo scopo la Commissione di gestione AQ si occupa di:

- verificare l'attuazione delle azioni di miglioramento approvate annualmente dal Consiglio di Corso nel documento di riesame;
- monitorare l'andamento delle carriere degli studenti, la loro opinione sulle attività formative, la soddisfazione al termine del percorso formativo e la condizione occupazionale dei laureati;
- condividere con il Consiglio di Corso i risultati del monitoraggio svolto.

L’Ateneo ha previsto che la Commissione di gestione AQ del Corso di studio sia composta  dal Coordinatore coadiuvato da altri componenti del Consiglio di Corso di studio inclusi i rappresentanti degli studenti:

Prof. Franco Callegati, Coordinatore del Corso di Studi

Prof. Vittorio Maniezzo

Prof. Alessandro Ricci

Prof. Matteo Ferrara

Prof. Roberto Girau

Prof. Vittorio Ghini

## Commissione Pratiche Studenti LT

La commissione pratiche studenti effettua il riconoscimento dei crediti formativi acquisiti in altri corsi di studio di questo o di altri atenei, comprese le abbreviazioni di corso. Esamina i piani di studio: scelte libere e piani di studio individuali. Gestisce l’accettazione corsi singoli ed eventuali richieste studenti.

Componenti della commissione

- Prof.ssa Antonella Carbonaro (Presidente)
- Prof. Lorenzo Pellegrini
- Prof. Giovanni Delnevo
- Prof. Franco Callegati (supplente)

Contatti: campuscesena.didattica.isa@unibo.it

## Commissione  Monocratica Tirocini LT

La commissione approva le domande di tirocinio sia curriculare interno ed esterno e tirocinio per tesi. Inoltre approva il riconoscimento della attività lavorativa.

Componenti della commissione

- Prof.ssa Damiana Lazzaro

Contatti: campuscesena.tirociniplacement@unibo.it

## Commissione Internazionalizzazione

La Commissione gestisce l’autorizzazione allo svolgimento delle attività formative all’estero contenute nei Learning Agreement e il relativo riconoscimento dei crediti formativi acquisiti dallo studente nell’ambito di scambi di mobilità, internazionale o nazionale.

Componenti della commissione:

- Prof. Danilo Pianini (Presidente)
- Prof. Luciano Margara
- Prof. Vittorio Maniezzo
- Prof. Franco Callegati (supplente)

Contatti: campuscesena.internazionalizzazioneingegneria@unibo.it

## Commissione Orientamento

La Commissione organizza iniziative volte a fornire informazioni sui contenuti del Corso di Laurea, consentendo ai futuri studenti di prendere una decisione più consapevole in merito all'iscrizione.

Referente

Prof.ssa Alessandra Lumini

- Sosteniamo il diritto alla conoscenza