# Bacheca

## Bandi

Mi interessa se: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando di concorso per l’assegnazione di contributi a favore di studenti con disabilità e a favore di studenti con disturbi dell’apprendimento iscritti all’A.A. 2024/2025

Scadenza: 17 giu 2025, 17:00

Consulta le borse di studio, gli esoneri, gli incentivi e i prossimi bandi in uscita.

Vai al sito dei bandi di Ateneo

## Notizie

### Idoneità linguistica.

Scopri quando puoi sostenerla: consulta il calendario delle prossime date e delle iscrizioni.

### Premio Tesi di Laurea “Ingenio al Femminile”

Il Consiglio Nazionale degli Ingegneri bandisce un concorso a premi riservato a donne ingegnere in tema  di "Intelligenza artificiale per le nuove sfide del 2050". Scadenza: 30 giugno.

### Tornano anche nel 2025 i Summer Camp “Ragazze Digitali”

Ser.In.Ar., in collaborazione con Art-ER e con il Dipartimento di Informatica – Scienza e Ingegneria dell’Università di Bologna, realizza anche quest’anno i 5 Summer Camp “Ragazze Digitali”.

## Eventi

Non ci sono eventi

## Eventi di orientamento

11
giu

### Incontra il corso

15:00

In presenza

- Sosteniamo il diritto alla conoscenza