# Esplora il Corso

Il Corso ti forma per progettare, sviluppare e gestire sistemi e applicazioni in ambito informatico, fornendo una cultura scientifica e ingegneristica di base e una conoscenza approfondita delle tecniche e metodologie di progettazione e degli strumenti più attuali per la realizzazione di soluzioni informatiche.

Iscrizioni aperte

## In breve

- Sede didattica

                                  
                                      Cesena
- Lingua

                                  
                                      Italiano
- Classe di corso
                          
                          
                              L-8 R - INGEGNERIA DELL'INFORMAZIONE
L-31 R - SCIENZE E TECNOLOGIE INFORMATICHE
- Durata

                                  
                                      3 anni

### Open day

Conosciamoci meglio. Quando possiamo incontrarci:

- 11
giu



ore 15:00

Incontra il corso

In presenza

## Cosa studierai

Il programma offre una formazione multidisciplinare con solide fondamenta teoriche ed empiriche per analisi approfondite, con un costante focus sulla prospettiva comparata e internazionale. Inoltre, include attività pratiche per un'applicazione concreta delle competenze acquisite.

### Insegnamenti

### Frequenza

Approfondisci nella 
                    pagina dedicata

## Profili professionali

Il corso offre diverse opportunità professionali, fornendoti le competenze per accedere a ruoli qualificati. Scopri i profili a cui potrai ambire:

- Analista, Progettista e Programmatore di Software
- Amministratore di Sistemi Informatici

## Esperienze all'estero

Nell'ambito delle esperienze all'estero, il Corso offre la possibilità di svolgere tirocini presso organizzazioni internazionali e partecipare a programmi di scambio. Queste esperienze offrono un contatto diretto con le realtà internazionali, arricchendo la comprensione delle dinamiche globali e fornendo un vantaggio concreto nel mercato del lavoro internazionale.

## Iscrizioni, tasse ed esenzioni

## Quanto costa iscriversi

Studiare all'Università di Bologna è un obiettivo raggiungibile a prescindere dalla tua situazione economica. 
              
Simula l'importo indicativo che dovrai pagare inserendo il tuo valore ISEE.

              Consulta tutte le informazioni sulle Tasse ed esenzioni: importi e scadenze.

### Tipologia di accesso

Numero programmato locale - TOLC-I
                    
                    , 244 
                      posti disponibili
                    

                  Per accedere al corso segui i passi che trovi nella pagina dedicata

## 5 motivi per iscriverti al corso

1. Ti permette di studiare l'informatica sia dal punto di vista matematico/scientifico, sia da quello progettuale/ingegneristico
2. Conoscerai le metodologie di progettazione e le tecnologie informatiche più attuali per la realizzazione di soluzioni informatiche
3. Continuo aggiornamento dei contenuti dei corsi, corpo docente giovane e attento alle tendenze più innovative
4. Il mondo del lavoro richiede un numero sempre maggiore di laureati in informatica
5. Un rapporto continuo e costruttivo con il corpo docente

## I numeri del corso

Alcuni dati sul corso: visita la pagina completa per approfondire e scoprire le opinioni di chi lo frequenta.

- 23%
        Studenti internazionali e fuori regione
- 30%
        Laureati in corso
- 5%
        Laureati con una esperienza all'estero
- 95%
        Laureati soddisfatti degli studi svolti
- 45%
        Laureati che lavorano
- 53%
        Laureati che non lavorano ma studiano o non cercano
- 2%
          Laureati che non lavorano e cercano

## Le esperienze di chi vive il corso

- Presentazione del corso







Guarda su YouTube

## Ricevi aggiornamenti sul corso

- Sosteniamo il diritto alla conoscenza