# Sistema di assicurazione di qualità

Il Corso, in linea con le azioni che l'Ateneo svolge per garantire la qualità della didattica e delle strutture, si impegna al miglioramento continuo attraverso il confronto con gli studenti e i rappresentanti del mondo del lavoro.
 Gli ambiti di intervento riguardano:

- la progettazione dei contenuti formativi e la pianificazione delle risorse;
- l'organizzazione delle attività formative e dei servizi didattici;
- la raccolta di dati e informazioni anche attraverso il confronto con gli studenti e i rappresentanti del mondo del lavoro;
- il monitoraggio dell'efficacia del percorso formativo e la programmazione di interventi di miglioramento della didattica e dei servizi.

Il Corso rende disponibili sul proprio sito informazioni complete e aggiornate sul progetto formativo (profili professionali formati, risultati di apprendimento attesi, attività formative), sulle risorse utilizzate e sui servizi didattici e sui risultati conseguiti.

- Sosteniamo il diritto alla conoscenza